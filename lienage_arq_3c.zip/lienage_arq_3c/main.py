"""
Ponto de entrada do projeto de linhagem automática.

Uso:
  # Linhagem de uma tabela específica
  python main.py --schema VENDAS --table FATO_PEDIDOS

  # Linhagem de todas as tabelas de um schema
  python main.py --schema VENDAS --all

  # Apenas mostrar o que foi encontrado, sem criar linhagem
  python main.py --schema VENDAS --table FATO_PEDIDOS --dry-run
"""

import argparse
import logging
import sys
import yaml
from pathlib import Path

from lineage_builder import LineageBuilder
from connectors.snowflake_connector import SnowflakeConnector

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("lineage_run.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


def load_config(path: str = "config/settings.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def print_result(result):
    print("\n" + "=" * 60)
    print(f"RESULTADO DE LINHAGEM: {result.table_fqn}")
    print("=" * 60)

    print(f"\n[INFORMATICA] {len(result.informatica_tasks)} task(s) encontrada(s):")
    for t in result.informatica_tasks:
        print(f"  - {t.get('task_name')} (tipo: {t.get('task_type')})")

    print(f"\n[AIRFLOW] {len(result.airflow_dags)} DAG(s) encontrada(s):")
    for d in result.airflow_dags:
        print(f"  - {d.get('dag_id')} | schedule: {d.get('schedule_interval')}")

    print(f"\n[QLIK CLOUD] {len(result.qlik_apps)} app(s) encontrado(s):")
    for a in result.qlik_apps:
        print(f"  - {a.get('app_name')} (id: {a.get('app_id')})")

    print(f"\n[LINHAGEM CRIADA] {len(result.lineage_edges_created)} aresta(s):")
    for edge in result.lineage_edges_created:
        print(f"  ✓ {edge}")

    if result.errors:
        print(f"\n[ERROS] {len(result.errors)}:")
        for err in result.errors:
            print(f"  ✗ {err}")

    print("=" * 60 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Linhagem automática: Informatica/Airflow → Snowflake → Qlik"
    )
    parser.add_argument("--schema", required=True, help="Schema Snowflake (ex: VENDAS)")
    parser.add_argument("--table", help="Nome da tabela (ex: FATO_PEDIDOS)")
    parser.add_argument(
        "--all",
        action="store_true",
        help="Processa todas as tabelas do schema",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Apenas mostra o que foi encontrado, sem criar linhagem no OpenMetadata",
    )
    parser.add_argument(
        "--config",
        default="config/settings.yaml",
        help="Caminho do arquivo de configuração",
    )
    args = parser.parse_args()

    if not args.table and not args.all:
        parser.error("Informe --table <nome> ou --all para processar todo o schema.")

    config = load_config(args.config)

    # Valida se há placeholders não preenchidos
    config_str = str(config)
    if "PREENCHER" in config_str:
        logger.warning(
            "ATENÇÃO: há campos com 'PREENCHER' no config/settings.yaml. "
            "Preencha as credenciais antes de executar em produção."
        )

    if args.dry_run:
        logger.info("Modo DRY-RUN ativado — linhagem NÃO será criada no OpenMetadata.")

    builder = LineageBuilder(config)

    tables_to_process = []

    if args.all:
        logger.info(f"Buscando todas as tabelas do schema {args.schema} no Snowflake...")
        sf_cfg = config["snowflake"]
        with SnowflakeConnector(
            account=sf_cfg["account"],
            user=sf_cfg["user"],
            password=sf_cfg["password"],
            warehouse=sf_cfg["warehouse"],
            database=sf_cfg["database"],
            role=sf_cfg["role"],
        ) as sf:
            rows = sf.find_tables_in_schema(args.schema)
            tables_to_process = [r["TABLE_NAME"] for r in rows]
        logger.info(f"  → {len(tables_to_process)} tabela(s) encontrada(s)")
    else:
        tables_to_process = [args.table]

    for table in tables_to_process:
        logger.info(f"\n{'─'*50}")
        logger.info(f"Processando: {args.schema}.{table}")

        if args.dry_run:
            # Em dry-run, apenas mostra sem criar linhagem
            # Roda apenas a descoberta
            result = builder.build_lineage_for_table(args.schema, table)
            result.lineage_edges_created = ["[dry-run: nenhuma aresta criada]"]
        else:
            result = builder.build_lineage_for_table(args.schema, table)

        print_result(result)

    logger.info("Concluído.")


if __name__ == "__main__":
    main()
