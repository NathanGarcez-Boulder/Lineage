"""
Lineage Builder — OpenMetadata
Uso:
  python main.py explore <tabela>
  python main.py build <tabela>
  python main.py build <tabela> --auto

Exemplos:
  python main.py explore TF_FATURAMENTO
  python main.py build TF_FATURAMENTO
  python main.py build TF_FATURAMENTO --auto

Flags:
  --auto    Seleciona automaticamente todas as entidades encontradas
            e pede só a confirmação final antes de criar.

Como funciona:
  Ao invés de buscar por nome, o script inspeciona o conteúdo real
  de cada pipeline (tasks/SQL) e dashboard (dataModels/charts) para
  encontrar os que de fato referenciam a tabela informada.
"""

import sys
from lineage_builder import LineageBuilder


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]
    table_name = sys.argv[2]
    args = sys.argv[3:]

    builder = LineageBuilder()

    if command == "explore":
        builder.explore(table_name)

    elif command == "build":
        auto = "--auto" in args
        builder.build(table_name, auto=auto)

    else:
        print(f"Comando desconhecido: {command}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
