"""
Linhagem automática: Snowflake → Qlik Cloud via OpenMetadata.

Uso:
  # Processa todos os apps Qlik e cria linhagem no OpenMetadata
  python main.py --all

  # Simula sem criar nada (recomendado na primeira execução)
  python main.py --all --dry-run

  # Processa um app específico pelo nome
  python main.py --app "Nome do App"

  # App específico em modo simulação
  python main.py --app "Nome do App" --dry-run
"""

import argparse
import logging
import sys

import yaml

from lineage_builder import LineageBuilder, LineageRunResult

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("lineage_run.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def print_summary(result: LineageRunResult, dry_run: bool):
    mode = " [DRY-RUN]" if dry_run else ""
    print(f"\n{'=' * 60}")
    print(f"RESUMO DA EXECUÇÃO{mode}")
    print(f"{'=' * 60}")
    print(f"  Apps processados:      {result.apps_processed}")
    print(f"  Apps com script:       {result.apps_with_script}")
    print(f"  Arestas criadas:       {result.total_edges_created}")
    print(f"  Ignoradas (não found): {result.total_edges_skipped}")
    print(f"  Erros:                 {result.total_errors}")

    if result.global_errors:
        print(f"\nErros globais:")
        for err in result.global_errors:
            print(f"  ✗ {err}")

    print(f"\nDetalhe por app:")
    for ar in result.app_results:
        status = f"{ar.created} criada(s)"
        if ar.skipped:
            status += f", {ar.skipped} ignorada(s)"
        if ar.errors:
            status += f", {ar.errors} erro(s)"
        print(f"  {ar.app_name}: {ar.tables_found} tabela(s) no script → {status}")

        # Exibe erros individuais
        for edge in ar.edges:
            if edge.status == "error":
                print(f"    ✗ {edge.table_fqn}: {edge.message}")

    print(f"{'=' * 60}\n")


def main():
    parser = argparse.ArgumentParser(
        description="Cria linhagem automática Snowflake → Qlik Cloud no OpenMetadata"
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--all",
        action="store_true",
        help="Processa todos os apps Qlik",
    )
    group.add_argument(
        "--app",
        metavar="NOME",
        help="Processa apenas o app com esse nome (busca parcial)",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simula a execução sem criar nada no OpenMetadata",
    )
    parser.add_argument(
        "--config",
        default="config/settings.yaml",
        help="Caminho do arquivo de configuração (padrão: config/settings.yaml)",
    )

    args = parser.parse_args()

    cfg = load_config(args.config)

    if "PREENCHER" in str(cfg):
        log.warning(
            "ATENÇÃO: há campos 'PREENCHER' no settings.yaml. "
            "Preencha as credenciais antes de executar em produção."
        )

    if args.dry_run:
        log.info("Modo DRY-RUN ativado — nenhuma linhagem será criada no OpenMetadata.")

    builder = LineageBuilder(cfg)

    result = builder.run(
        app_name_filter=args.app,
        dry_run=args.dry_run,
    )

    print_summary(result, dry_run=args.dry_run)

    if result.total_errors > 0:
        log.warning(f"{result.total_errors} erro(s) durante a execução. Veja lineage_run.log.")
        sys.exit(1)


if __name__ == "__main__":
    main()
