"""
Lineage Builder — OpenMetadata
Uso:
  python main.py explore <tabela>
  python main.py build <tabela>
  python main.py build <tabela> --auto
  python main.py build <tabela> --pipeline <nome> --dashboard <nome>

Exemplos:
  python main.py explore TF_CICLO_PEDIDO
  python main.py build TF_CICLO_PEDIDO
  python main.py build TF_CICLO_PEDIDO --auto
  python main.py build TF_CICLO_PEDIDO --pipeline dag_vendas --dashboard painel_comercial

Flags:
  --auto        Linka DAGs Airflow automaticamente pelo nome da tabela.
                Informatica e Qlik ainda pedem seleção manual.
  --pipeline    Filtra pipelines pelo nome informado (Airflow e Informatica)
  --dashboard   Filtra dashboards pelo nome informado
"""

import sys
from lineage_builder import LineageBuilder


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]
    table_name = sys.argv[2]
    args = sys.argv[3:]

    builder = LineageBuilder()

    if command == "explore":
        builder.explore(table_name)

    elif command == "build":
        pipeline_name = None
        dashboard_name = None
        auto = "--auto" in args

        for i, arg in enumerate(args):
            if arg == "--pipeline" and i + 1 < len(args):
                pipeline_name = args[i + 1]
            if arg == "--dashboard" and i + 1 < len(args):
                dashboard_name = args[i + 1]

        builder.build(
            table_name,
            pipeline_name=pipeline_name,
            dashboard_name=dashboard_name,
            auto=auto,
        )

    else:
        print(f"Comando desconhecido: {command}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
