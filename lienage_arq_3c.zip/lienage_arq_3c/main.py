#!/usr/bin/env python3
"""
Robô de linhagem automática — Snowflake → Qlik Cloud → OpenMetadata

Uso:
  python main.py --table MINHA_BASE.MEU_SCHEMA.MINHA_TABELA
  python main.py --table MINHA_BASE.MEU_SCHEMA.MINHA_TABELA --dry-run
  python main.py --table MINHA_BASE.MEU_SCHEMA.MINHA_TABELA --verbose
  python main.py --table MINHA_BASE.MEU_SCHEMA.MINHA_TABELA --config outro_settings.yaml
"""

import argparse
import sys

from lineage_builder import run


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gera linhagem Snowflake → Qlik no OpenMetadata.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--table", "-t",
        required=True,
        metavar="DB.SCHEMA.TABLE",
        help="Nome completo da tabela Snowflake (ex: VENDAS.PUBLIC.FATO_PEDIDOS)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Mostra o que seria feito sem criar linhagem no OpenMetadata.",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Exibe progresso detalhado ao varrer apps Qlik.",
    )
    parser.add_argument(
        "--config",
        default="config/settings.yaml",
        metavar="ARQUIVO",
        help="Caminho para o arquivo de configuração (padrão: config/settings.yaml)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # Valida formato básico do FQN
    parts = args.table.split(".")
    if len(parts) != 3:
        print(f"[ERRO] --table deve estar no formato DATABASE.SCHEMA.TABLE")
        print(f"       Recebido: '{args.table}'")
        sys.exit(1)

    try:
        run(
            table_fqn=args.table,
            dry_run=args.dry_run,
            verbose=args.verbose,
            config_path=args.config,
        )
    except FileNotFoundError as e:
        print(f"[ERRO] Arquivo não encontrado: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERRO] {type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
