"""
Lineage Builder — OpenMetadata
Uso:
  python main.py explore <nome_da_tabela>
  python main.py build <nome_da_tabela>
  python main.py build <nome_da_tabela> --pipeline <nome_pipeline> --dashboard <nome_dashboard>

Exemplos:
  python main.py explore VENDAS_DIARIAS
  python main.py build VENDAS_DIARIAS
  python main.py build VENDAS_DIARIAS --pipeline dag_vendas --dashboard painel_comercial
"""

import sys
from lineage_builder import LineageBuilder


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]
    table_name = sys.argv[2]

    builder = LineageBuilder()

    if command == "explore":
        builder.explore(table_name)

    elif command == "build":
        pipeline_name = None
        dashboard_name = None

        args = sys.argv[3:]
        for i, arg in enumerate(args):
            if arg == "--pipeline" and i + 1 < len(args):
                pipeline_name = args[i + 1]
            if arg == "--dashboard" and i + 1 < len(args):
                dashboard_name = args[i + 1]

        builder.build(table_name, pipeline_name=pipeline_name, dashboard_name=dashboard_name)

    else:
        print(f"Comando desconhecido: {command}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
