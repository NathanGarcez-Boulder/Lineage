import requests
import os
from dotenv import load_dotenv

load_dotenv()


class OpenMetadataClient:
    def __init__(self):
        host = os.getenv("OM_HOST")
        token = os.getenv("OM_TOKEN")

        if not host or not token:
            raise EnvironmentError(
                "Variáveis OM_HOST e OM_TOKEN não encontradas.\n"
                "Crie um arquivo .env na pasta do projeto com:\n"
                "  OM_HOST=https://seu-openmetadata.com\n"
                "  OM_TOKEN=seu_jwt_token"
            )

        self.base_url = host.rstrip("/") + "/api/v1"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _get(self, path, params=None):
        r = requests.get(f"{self.base_url}{path}", headers=self.headers, params=params)
        r.raise_for_status()
        return r.json()

    def _put(self, path, body):
        r = requests.put(f"{self.base_url}{path}", headers=self.headers, json=body)
        r.raise_for_status()
        # A API de linhagem pode retornar 200 com JSON ou 204 sem corpo
        if r.content:
            return r.json()
        return {"status": r.status_code}

    def search(self, query, entity_type=None, size=50):
        """Busca entidades no OpenMetadata pelo nome."""
        params = {"q": query, "from": 0, "size": size}
        if entity_type:
            params["index"] = entity_type
        return self._get("/search/query", params=params)

    def get_table_by_name(self, table_name):
        """Busca uma tabela Snowflake pelo nome (parcial)."""
        results = self.search(table_name, entity_type="table_search_index")
        hits = results.get("hits", {}).get("hits", [])
        return [h["_source"] for h in hits]

    def get_pipelines_by_name(self, name):
        """Busca pipelines (Airflow/Informatica) pelo nome."""
        results = self.search(name, entity_type="pipeline_search_index")
        hits = results.get("hits", {}).get("hits", [])
        return [h["_source"] for h in hits]

    def get_dashboards_by_name(self, name):
        """Busca dashboards Qlik pelo nome."""
        results = self.search(name, entity_type="dashboard_search_index")
        hits = results.get("hits", {}).get("hits", [])
        return [h["_source"] for h in hits]

    def get_lineage(self, entity_type, entity_id, upstream=3, downstream=3):
        """Retorna linhagem existente de uma entidade."""
        return self._get(
            f"/lineage/{entity_type}/{entity_id}",
            params={"upstreamDepth": upstream, "downstreamDepth": downstream},
        )

    def add_lineage_edge(self, from_id, from_type, to_id, to_type):
        """Cria uma edge de linhagem entre duas entidades."""
        body = {
            "edge": {
                "fromEntity": {"id": from_id, "type": from_type},
                "toEntity": {"id": to_id, "type": to_type},
            }
        }
        return self._put("/lineage", body)
