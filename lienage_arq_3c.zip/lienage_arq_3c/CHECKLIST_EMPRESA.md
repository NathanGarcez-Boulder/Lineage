# Checklist — O que preencher no computador da empresa

## 1. Instalar dependências
```bash
pip install -r requirements.txt
```

## 2. Preencher config/settings.yaml

Abra o arquivo e substitua cada `PREENCHER` com os valores reais:

### OpenMetadata
- [ ] `host` — URL do servidor OpenMetadata (ex: `http://openmetadata.empresa.com:8585`)
- [ ] `jwt_token` — Gerar em: OpenMetadata → Settings → Bots → Criar bot → copiar JWT

### Snowflake
- [ ] `account` — Identificador da conta (ex: `abc123.us-east-1`)
- [ ] `user` — Usuário de serviço com permissão de leitura
- [ ] `password`
- [ ] `warehouse`
- [ ] `database` — Database principal do DW
- [ ] `role`

### Informatica Cloud (IICS)
- [ ] `base_url` — Verificar a região: `https://dm-us.informaticacloud.com` (US) ou `https://dm-em.informaticacloud.com` (Europa)
- [ ] `username`
- [ ] `password`
- [ ] `org_id` — Disponível em: IICS → Administration → Organization → Organization ID

### Airflow
- [ ] `base_url` — URL do Airflow com porta (ex: `http://airflow.empresa.com:8080`)
- [ ] `username`
- [ ] `password`

### Qlik Cloud
- [ ] `tenant_url` — Ex: `https://empresa.us.qlikcloud.com`
- [ ] `api_key` — Gerar em: Qlik Cloud → Management Console → API Keys → Create new

### Nomes dos serviços no OpenMetadata
- [ ] `snowflake_service_name` — Nome exato como está cadastrado no OpenMetadata
- [ ] `qlik_service_name`
- [ ] `informatica_service_name`
- [ ] `airflow_service_name`
- [ ] `default_schema`

## 3. Testar a conexão
```bash
# Primeiro dry-run para ver o que é encontrado sem criar linhagem
python main.py --schema SEU_SCHEMA --table SUA_TABELA --dry-run

# Se ok, rodar de verdade
python main.py --schema SEU_SCHEMA --table SUA_TABELA
```

## 4. Rodar para todo o schema
```bash
python main.py --schema SEU_SCHEMA --all
```

## Logs
O arquivo `lineage_run.log` é gerado na pasta do projeto com o histórico completo de execução.
