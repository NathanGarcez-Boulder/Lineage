"""
Conector Apache Airflow.
Busca DAGs e tasks que referenciam uma tabela Snowflake.
"""

import requests
from typing import Optional
from base64 import b64encode


class AirflowConnector:
    def __init__(self, base_url: str, username: str, password: str):
        self.base_url = base_url.rstrip("/")
        token = b64encode(f"{username}:{password}".encode()).decode()
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Basic {token}",
            "Content-Type": "application/json",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self.base_url}/api/v1{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def list_dags(self, only_active: bool = True) -> list[dict]:
        params = {"only_active": only_active, "limit": 200}
        result = self._get("/dags", params=params)
        return result.get("dags", [])

    def get_dag_detail(self, dag_id: str) -> dict:
        return self._get(f"/dags/{dag_id}/details")

    def get_dag_tasks(self, dag_id: str) -> list[dict]:
        result = self._get(f"/dags/{dag_id}/tasks")
        return result.get("tasks", [])

    def get_dag_source(self, dag_id: str) -> Optional[str]:
        """Retorna o código-fonte do DAG."""
        try:
            result = self._get(f"/dags/{dag_id}/source")
            return result.get("source", "")
        except Exception:
            return None

    def find_dags_referencing_table(self, table_name: str) -> list[dict]:
        """
        Busca DAGs cujo código-fonte menciona a tabela.
        Estratégia: lê o source de cada DAG e faz busca por string.
        """
        matches = []
        dags = self.list_dags()
        table_upper = table_name.upper()

        for dag in dags:
            dag_id = dag["dag_id"]
            source = self.get_dag_source(dag_id) or ""
            if table_upper in source.upper():
                matches.append({
                    "dag_id": dag_id,
                    "description": dag.get("description", ""),
                    "tags": [t["name"] for t in dag.get("tags", [])],
                    "is_active": dag.get("is_active"),
                    "schedule_interval": dag.get("schedule_interval"),
                    "owners": dag.get("owners", []),
                })

        return matches

    def get_task_instances(self, dag_id: str, limit: int = 10) -> list[dict]:
        """Retorna execuções recentes de um DAG."""
        result = self._get(
            f"/dags/{dag_id}/dagRuns",
            params={"limit": limit, "order_by": "-execution_date"},
        )
        return result.get("dag_runs", [])
