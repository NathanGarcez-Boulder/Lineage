"""
Conector Snowflake com autenticação por key pair (RSA).
"""

import snowflake.connector
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pathlib import Path


def _load_private_key(key_path: str, passphrase: str | None) -> bytes:
    """Carrega a chave privada RSA e retorna em formato DER (exigido pelo conector Snowflake)."""
    path = Path(key_path)
    if not path.exists():
        raise FileNotFoundError(f"Chave privada não encontrada: {key_path}")

    with path.open("rb") as f:
        raw = f.read()

    password = passphrase.encode() if passphrase else None

    private_key = serialization.load_pem_private_key(
        raw,
        password=password,
        backend=default_backend(),
    )

    return private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def get_connection(cfg: dict) -> snowflake.connector.SnowflakeConnection:
    """Abre e retorna uma conexão Snowflake autenticada via key pair."""
    private_key_bytes = _load_private_key(
        cfg["private_key_path"],
        cfg.get("private_key_passphrase") or None,
    )

    conn = snowflake.connector.connect(
        account=cfg["account"],
        user=cfg["user"],
        private_key=private_key_bytes,
        role=cfg.get("role"),
        warehouse=cfg.get("warehouse"),
        database=cfg.get("database"),
    )
    return conn


def validate_table(conn: snowflake.connector.SnowflakeConnection, fqn: str) -> dict | None:
    """
    Verifica se a tabela existe no Snowflake e retorna seus metadados básicos.

    fqn: fully-qualified name no formato DATABASE.SCHEMA.TABLE
    Retorna dict com database, schema, table ou None se não encontrar.
    """
    parts = fqn.upper().split(".")
    if len(parts) != 3:
        raise ValueError(f"Informe o nome no formato DATABASE.SCHEMA.TABLE — recebido: {fqn}")

    database, schema, table = parts

    query = f"""
        SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE, ROW_COUNT, BYTES
        FROM {database}.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = '{schema}'
          AND TABLE_NAME   = '{table}'
    """

    cur = conn.cursor()
    try:
        cur.execute(query)
        row = cur.fetchone()
    finally:
        cur.close()

    if not row:
        return None

    return {
        "database": row[0],
        "schema": row[1],
        "table": row[2],
        "type": row[3],
        "rows": row[4],
        "bytes": row[5],
        "fqn": f"{row[0]}.{row[1]}.{row[2]}",
    }
