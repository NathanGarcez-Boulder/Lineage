"""
Conector Snowflake.
Busca tabelas e suas dependências (VIEW references, streams, etc.)
"""

import snowflake.connector
from typing import Optional


class SnowflakeConnector:
    def __init__(self, account: str, user: str, password: str,
                 warehouse: str, database: str, role: str):
        self.config = dict(
            account=account,
            user=user,
            password=password,
            warehouse=warehouse,
            database=database,
            role=role,
        )
        self._conn: Optional[snowflake.connector.SnowflakeConnection] = None

    def connect(self):
        self._conn = snowflake.connector.connect(**self.config)

    def close(self):
        if self._conn:
            self._conn.close()

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()

    def _cursor(self):
        return self._conn.cursor(snowflake.connector.DictCursor)

    def table_exists(self, schema: str, table: str) -> bool:
        cur = self._cursor()
        cur.execute(
            "SELECT COUNT(*) AS cnt FROM information_schema.tables "
            "WHERE table_schema = %s AND table_name = %s",
            (schema.upper(), table.upper()),
        )
        row = cur.fetchone()
        return row["CNT"] > 0

    def get_table_info(self, schema: str, table: str) -> Optional[dict]:
        """Retorna metadados básicos da tabela."""
        cur = self._cursor()
        cur.execute(
            "SELECT table_name, table_schema, table_type, row_count, "
            "bytes, comment, created, last_altered "
            "FROM information_schema.tables "
            "WHERE table_schema = %s AND table_name = %s",
            (schema.upper(), table.upper()),
        )
        return cur.fetchone()

    def get_columns(self, schema: str, table: str) -> list[dict]:
        cur = self._cursor()
        cur.execute(
            "SELECT column_name, data_type, is_nullable, column_default, comment "
            "FROM information_schema.columns "
            "WHERE table_schema = %s AND table_name = %s "
            "ORDER BY ordinal_position",
            (schema.upper(), table.upper()),
        )
        return cur.fetchall()

    def find_tables_in_schema(self, schema: str, name_filter: str = None) -> list[dict]:
        """Lista tabelas de um schema, com filtro opcional por nome."""
        query = (
            "SELECT table_name, table_schema, table_type "
            "FROM information_schema.tables "
            "WHERE table_schema = %s"
        )
        params = [schema.upper()]
        if name_filter:
            query += " AND table_name ILIKE %s"
            params.append(f"%{name_filter}%")
        query += " ORDER BY table_name"
        cur = self._cursor()
        cur.execute(query, params)
        return cur.fetchall()

    def get_qlik_query_history(self, days: int = 30, qlik_users: list[str] = None) -> list[dict]:
        """
        Retorna queries SELECT executadas por sessões Qlik no período.

        Filtra por CLIENT_APPLICATION_NAME LIKE '%qlik%' e/ou por lista de
        usuários Snowflake configurados para o Qlik (ex: SVC_QLIK).

        Requer acesso à view SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
        (role ACCOUNTADMIN ou grant explícito em IMPORTED PRIVILEGES).
        """
        cur = self._cursor()

        user_filter_parts = ["LOWER(client_application_name) LIKE '%qlik%'"]
        if qlik_users:
            placeholders = ", ".join(f"'{u.upper()}'" for u in qlik_users)
            user_filter_parts.append(f"UPPER(user_name) IN ({placeholders})")

        user_filter = " OR ".join(user_filter_parts)

        cur.execute(
            f"""
            SELECT
                query_id,
                query_text,
                user_name,
                database_name,
                schema_name,
                client_application_name,
                start_time,
                query_type
            FROM snowflake.account_usage.query_history
            WHERE
                execution_status = 'SUCCESS'
                AND start_time >= DATEADD(day, -{days}, CURRENT_TIMESTAMP())
                AND query_type IN ('SELECT', 'UNKNOWN')
                AND ({user_filter})
            ORDER BY start_time DESC
            """
        )
        return cur.fetchall()

    def get_query_history_sources(self, schema: str, table: str, days: int = 30) -> list[dict]:
        """
        Usa QUERY_HISTORY para encontrar queries que escrevem na tabela.
        Útil para rastrear ETLs que fazem INSERT/COPY INTO.
        """
        cur = self._cursor()
        cur.execute(
            f"""
            SELECT DISTINCT
                query_text,
                user_name,
                role_name,
                warehouse_name,
                start_time,
                query_type
            FROM snowflake.account_usage.query_history
            WHERE
                execution_status = 'SUCCESS'
                AND start_time >= DATEADD(day, -{days}, CURRENT_TIMESTAMP())
                AND (
                    UPPER(query_text) LIKE UPPER('%INTO%{schema}%.{table}%')
                    OR UPPER(query_text) LIKE UPPER('%{schema}%.{table}%INSERT%')
                    OR UPPER(query_text) LIKE UPPER('%COPY INTO%{table}%')
                )
            ORDER BY start_time DESC
            LIMIT 100
            """,
        )
        return cur.fetchall()
