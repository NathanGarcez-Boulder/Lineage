"""
Cliente para a API do OpenMetadata v1.12+.
Busca entidades (tabelas, dashboards, pipelines) e cria arestas de linhagem.
"""

import logging
from typing import Optional

import requests

log = logging.getLogger(__name__)


class OpenMetadataClient:
    def __init__(self, host: str, jwt_token: str):
        self.host = host.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {jwt_token}",
            "Content-Type": "application/json",
        })

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self.host}/api/v1{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def _put(self, path: str, payload: dict) -> dict:
        resp = self.session.put(f"{self.host}/api/v1{path}", json=payload)
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Tabelas
    # ------------------------------------------------------------------

    def get_table(self, fqn: str) -> Optional[dict]:
        """
        Busca tabela pelo FQN. Retorna None se não existir.
        FQN Snowflake: <service>.<database>.<schema>.<table>
        """
        try:
            return self._get(f"/tables/name/{requests.utils.quote(fqn, safe='')}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def search_tables(self, query: str, service: str = None, size: int = 50) -> list[dict]:
        """Busca tabelas por nome parcial."""
        q = query
        if service:
            q = f"{query} AND (service.name:{service})"
        result = self._get("/search/query", params={
            "q": q, "index": "table_search_index", "from": 0, "size": size,
        })
        return result.get("hits", {}).get("hits", [])

    def list_tables(self, service_name: str) -> list[dict]:
        """
        Lista todas as tabelas de um serviço com paginação completa.
        Retorna lista de entidades com id, name, fullyQualifiedName.
        """
        tables = []
        params = {
            "service": service_name,
            "limit": 100,
            "fields": "id,name,fullyQualifiedName,databaseSchema",
        }
        while True:
            resp = self._get("/tables", params=params)
            data = resp.get("data", [])
            tables.extend(data)
            paging = resp.get("paging", {})
            after = paging.get("after")
            if not after or not data:
                break
            params = {**params, "after": after}
        return tables

    # ------------------------------------------------------------------
    # Dashboards (Qlik)
    # ------------------------------------------------------------------

    def get_dashboard(self, fqn: str) -> Optional[dict]:
        """Busca dashboard pelo FQN. Retorna None se não existir."""
        try:
            return self._get(f"/dashboards/name/{requests.utils.quote(fqn, safe='')}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def search_dashboards(self, query: str, service: str = None, size: int = 50) -> list[dict]:
        """Busca dashboards por nome parcial."""
        q = query
        if service:
            q = f"{query} AND (service.name:{service})"
        result = self._get("/search/query", params={
            "q": q, "index": "dashboard_search_index", "from": 0, "size": size,
        })
        return result.get("hits", {}).get("hits", [])

    def list_dashboards(self, service_name: str) -> list[dict]:
        """
        Lista todos os dashboards de um serviço com paginação completa.
        Retorna lista de entidades com id, name, fullyQualifiedName, displayName.
        """
        dashboards = []
        params = {
            "service": service_name,
            "limit": 100,
            "fields": "id,name,fullyQualifiedName,displayName",
        }
        while True:
            resp = self._get("/dashboards", params=params)
            data = resp.get("data", [])
            dashboards.extend(data)
            paging = resp.get("paging", {})
            after = paging.get("after")
            if not after or not data:
                break
            params = {**params, "after": after}
        return dashboards

    # ------------------------------------------------------------------
    # Pipelines (para uso futuro com Airflow / Informatica)
    # ------------------------------------------------------------------

    def get_pipeline(self, fqn: str) -> Optional[dict]:
        try:
            return self._get(f"/pipelines/name/{requests.utils.quote(fqn, safe='')}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def list_pipelines(self, service_name: str) -> list[dict]:
        """Lista todos os pipelines de um serviço com paginação completa."""
        pipelines = []
        params = {
            "service": service_name,
            "limit": 100,
            "fields": "id,name,fullyQualifiedName,displayName",
        }
        while True:
            resp = self._get("/pipelines", params=params)
            data = resp.get("data", [])
            pipelines.extend(data)
            paging = resp.get("paging", {})
            after = paging.get("after")
            if not after or not data:
                break
            params = {**params, "after": after}
        return pipelines

    # ------------------------------------------------------------------
    # Linhagem
    # ------------------------------------------------------------------

    def add_lineage(
        self,
        from_entity_type: str,
        from_id: str,
        to_entity_type: str,
        to_id: str,
        description: str = "",
        source: str = "DashboardLineage",
    ) -> dict:
        """
        Cria uma aresta de linhagem entre dois nós pelo ID das entidades.

        from/to entity_type: 'table' | 'dashboard' | 'pipeline'
        source: 'Manual' | 'QueryLineage' | 'DashboardLineage' | 'PipelineLineage'
        """
        payload = {
            "edge": {
                "fromEntity": {"id": from_id, "type": from_entity_type},
                "toEntity": {"id": to_id, "type": to_entity_type},
                "description": description,
                "lineageDetails": {
                    "source": source,
                    "columnsLineage": [],
                },
            }
        }
        return self._put("/lineage", payload)

    def get_lineage(self, entity_type: str, entity_id: str, depth: int = 3) -> dict:
        """Retorna o grafo de linhagem de uma entidade pelo ID."""
        return self._get(
            f"/lineage/{entity_type}/{entity_id}",
            params={"upstreamDepth": depth, "downstreamDepth": depth},
        )
