"""
Cliente OpenMetadata — resolve entidades e cria arestas de linhagem.
"""

import requests


class OpenMetadataClient:
    def __init__(self, host: str, jwt_token: str):
        self.base = host.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {jwt_token}",
            "Content-Type": "application/json",
        })

    # ------------------------------------------------------------------
    # Resolução de entidades
    # ------------------------------------------------------------------

    def get_table_entity(self, service_name: str, table_fqn: str) -> dict | None:
        """
        Localiza uma tabela no OpenMetadata.
        table_fqn: DATABASE.SCHEMA.TABLE (sem o nome do serviço)
        Retorna o entity dict ou None.
        """
        # FQN no OpenMetadata: <service>.<database>.<schema>.<table>
        db, schema, table = table_fqn.upper().split(".")
        om_fqn = f"{service_name}.{db}.{schema}.{table}"
        url = f"{self.base}/api/v1/tables/name/{om_fqn}"
        resp = self.session.get(url, params={"fields": "id,fullyQualifiedName"})
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    def get_dashboard_entity(self, service_name: str, app_name: str) -> dict | None:
        """
        Localiza um dashboard (app Qlik) no OpenMetadata pelo nome do app.
        Retorna o entity dict ou None.
        """
        # Tenta pelo FQN direto: <service>.<app_name>
        om_fqn = f"{service_name}.{app_name}"
        url = f"{self.base}/api/v1/dashboards/name/{requests.utils.quote(om_fqn, safe='')}"
        resp = self.session.get(url, params={"fields": "id,fullyQualifiedName"})
        if resp.status_code == 404:
            # Fallback: busca por nome
            return self._search_dashboard(service_name, app_name)
        resp.raise_for_status()
        return resp.json()

    def _search_dashboard(self, service_name: str, app_name: str) -> dict | None:
        url = f"{self.base}/api/v1/search/query"
        params = {
            "q": app_name,
            "index": "dashboard_search_index",
            "from": 0,
            "size": 10,
        }
        resp = self.session.get(url, params=params)
        if resp.status_code != 200:
            return None
        hits = resp.json().get("hits", {}).get("hits", [])
        for hit in hits:
            src = hit.get("_source", {})
            if src.get("service", {}).get("name") == service_name:
                return {"id": src["id"], "fullyQualifiedName": src["fullyQualifiedName"]}
        return None

    # ------------------------------------------------------------------
    # Criação de linhagem
    # ------------------------------------------------------------------

    def create_lineage_edge(
        self,
        from_entity: dict,
        from_type: str,
        to_entity: dict,
        to_type: str,
        description: str = "",
    ) -> bool:
        """
        Cria uma aresta de linhagem no OpenMetadata.

        from_entity / to_entity: dict com 'id' e 'fullyQualifiedName'
        from_type / to_type: 'table' | 'dashboard'
        Retorna True se criado com sucesso.
        """
        payload = {
            "edge": {
                "fromEntity": {
                    "id": from_entity["id"],
                    "type": from_type,
                    "fullyQualifiedName": from_entity["fullyQualifiedName"],
                },
                "toEntity": {
                    "id": to_entity["id"],
                    "type": to_type,
                    "fullyQualifiedName": to_entity["fullyQualifiedName"],
                },
                "description": description,
            }
        }

        resp = self.session.put(f"{self.base}/api/v1/lineage", json=payload)
        if resp.status_code in (200, 201):
            return True

        # 409 = já existe (idempotente)
        if resp.status_code == 409:
            return True

        resp.raise_for_status()
        return False

    def lineage_exists(self, from_id: str, to_id: str) -> bool:
        """Verifica se a aresta de linhagem já existe."""
        url = f"{self.base}/api/v1/lineage/getLineage"
        params = {"id": from_id, "type": "table", "upstreamDepth": 0, "downstreamDepth": 1}
        resp = self.session.get(url, params=params)
        if resp.status_code != 200:
            return False
        edges = resp.json().get("downstreamEdges", [])
        return any(e.get("toEntity", {}).get("id") == to_id for e in edges)
