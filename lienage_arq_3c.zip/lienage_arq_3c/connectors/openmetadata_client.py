"""
Cliente para a API do OpenMetadata.
Responsável por buscar entidades e criar linhagem.
"""

import requests
from typing import Optional


class OpenMetadataClient:
    def __init__(self, host: str, jwt_token: str):
        self.host = host.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {jwt_token}",
            "Content-Type": "application/json",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self.host}/api/v1{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def _put(self, path: str, payload: dict) -> dict:
        resp = self.session.put(f"{self.host}/api/v1{path}", json=payload)
        resp.raise_for_status()
        return resp.json()

    def _patch(self, path: str, payload: list) -> dict:
        headers = {"Content-Type": "application/json-patch+json"}
        resp = self.session.patch(
            f"{self.host}/api/v1{path}", json=payload, headers=headers
        )
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Tabelas
    # ------------------------------------------------------------------

    def get_table(self, fqn: str) -> Optional[dict]:
        """
        Busca uma tabela pelo Fully Qualified Name.
        FQN padrão Snowflake no OpenMetadata:
          <service>.<database>.<schema>.<table>
        """
        try:
            return self._get(f"/tables/name/{fqn}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def search_tables(self, query: str, service: str = None) -> list[dict]:
        """Busca tabelas por nome parcial."""
        params = {"q": query, "index": "table_search_index", "from": 0, "size": 50}
        if service:
            params["q"] = f"{query} AND (service.name:{service})"
        result = self._get("/search/query", params=params)
        return result.get("hits", {}).get("hits", [])

    # ------------------------------------------------------------------
    # Pipelines (ETL)
    # ------------------------------------------------------------------

    def get_pipeline(self, fqn: str) -> Optional[dict]:
        try:
            return self._get(f"/pipelines/name/{fqn}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def search_pipelines(self, query: str, service: str = None) -> list[dict]:
        params = {"q": query, "index": "pipeline_search_index", "from": 0, "size": 50}
        if service:
            params["q"] = f"{query} AND (service.name:{service})"
        result = self._get("/search/query", params=params)
        return result.get("hits", {}).get("hits", [])

    # ------------------------------------------------------------------
    # Dashboards (Qlik)
    # ------------------------------------------------------------------

    def get_dashboard(self, fqn: str) -> Optional[dict]:
        try:
            return self._get(f"/dashboards/name/{fqn}")
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def search_dashboards(self, query: str, service: str = None) -> list[dict]:
        params = {"q": query, "index": "dashboard_search_index", "from": 0, "size": 50}
        if service:
            params["q"] = f"{query} AND (service.name:{service})"
        result = self._get("/search/query", params=params)
        return result.get("hits", {}).get("hits", [])

    # ------------------------------------------------------------------
    # Linhagem
    # ------------------------------------------------------------------

    def add_lineage(
        self,
        from_entity_type: str,
        from_fqn: str,
        to_entity_type: str,
        to_fqn: str,
        description: str = "",
    ) -> dict:
        """
        Cria uma aresta de linhagem entre dois nós.

        entity_type: 'table' | 'pipeline' | 'dashboard'
        """
        from_entity = self._get_entity_ref(from_entity_type, from_fqn)
        to_entity = self._get_entity_ref(to_entity_type, to_fqn)

        payload = {
            "edge": {
                "fromEntity": {"id": from_entity["id"], "type": from_entity_type},
                "toEntity": {"id": to_entity["id"], "type": to_entity_type},
                "description": description,
            }
        }
        return self._put("/lineage", payload)

    def _get_entity_ref(self, entity_type: str, fqn: str) -> dict:
        routes = {
            "table": f"/tables/name/{fqn}",
            "pipeline": f"/pipelines/name/{fqn}",
            "dashboard": f"/dashboards/name/{fqn}",
        }
        path = routes.get(entity_type)
        if not path:
            raise ValueError(f"Tipo de entidade desconhecido: {entity_type}")
        return self._get(path)

    def get_lineage(self, entity_type: str, fqn: str, depth: int = 3) -> dict:
        """Retorna o grafo de linhagem de uma entidade."""
        entity = self._get_entity_ref(entity_type, fqn)
        return self._get(
            f"/lineage/{entity_type}/{entity['id']}",
            params={"upstreamDepth": depth, "downstreamDepth": depth},
        )
