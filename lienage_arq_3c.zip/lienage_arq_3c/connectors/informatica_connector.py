"""
Conector Informatica Cloud (IICS).
Busca mappings/tasks que escrevem em uma tabela Snowflake específica.
"""

import requests
from typing import Optional


class InformaticaConnector:
    def __init__(self, base_url: str, username: str, password: str, org_id: str):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.org_id = org_id
        self._session_id: Optional[str] = None
        self._server_url: Optional[str] = None
        self.session = requests.Session()

    def login(self):
        """Autentica no IICS e obtém session ID."""
        resp = self.session.post(
            f"{self.base_url}/ma/api/v2/user/login",
            json={"@type": "login", "username": self.username, "password": self.password},
        )
        resp.raise_for_status()
        data = resp.json()
        self._session_id = data["userInfo"]["sessionId"]
        self._server_url = data["userInfo"]["serverUrl"]
        self.session.headers.update({"icSessionId": self._session_id})

    def logout(self):
        if self._session_id:
            self.session.post(f"{self._server_url}/ma/api/v2/user/logout")

    def __enter__(self):
        self.login()
        return self

    def __exit__(self, *args):
        self.logout()

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self._server_url}{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def list_mappings(self) -> list[dict]:
        """Lista todos os mappings da organização."""
        result = self._get("/api/v2/mapping", params={"q": "type==Mapping"})
        return result if isinstance(result, list) else result.get("mapping", [])

    def get_mapping_detail(self, mapping_id: str) -> dict:
        return self._get(f"/api/v2/mapping/{mapping_id}")

    def list_tasks(self, task_type: str = "MTT") -> list[dict]:
        """
        Lista tasks de um tipo.
        task_type: MTT (Mapping Task), DSS (Data Sync), etc.
        """
        result = self._get(f"/api/v2/task", params={"type": task_type})
        return result if isinstance(result, list) else result.get("task", [])

    def find_tasks_writing_to_table(self, target_table: str) -> list[dict]:
        """
        Encontra tasks/mappings que escrevem na tabela alvo.
        Faz busca por nome de tabela nos targets de cada task.
        """
        matches = []
        tasks = self.list_tasks()
        target_upper = target_table.upper()

        for task in tasks:
            task_id = task.get("id") or task.get("taskId")
            try:
                detail = self.get_mapping_detail(task_id)
                # Verifica targets do mapping
                targets = detail.get("fieldMapping", {}).get("targetFields", [])
                for target in targets:
                    obj_name = (target.get("objectName") or "").upper()
                    if target_upper in obj_name:
                        matches.append({
                            "task_id": task_id,
                            "task_name": task.get("name"),
                            "task_type": task.get("type"),
                            "target_object": target.get("objectName"),
                        })
                        break
            except Exception:
                # Ignora tasks sem acesso ou com estrutura diferente
                continue

        return matches

    def get_task_connections(self, task_id: str) -> dict:
        """Retorna conexões de origem e destino de uma task."""
        detail = self.get_mapping_detail(task_id)
        return {
            "sources": detail.get("sources", []),
            "targets": detail.get("targets", []),
        }
