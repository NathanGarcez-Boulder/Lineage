"""
Conector Qlik Cloud — lista apps e parseia load scripts em busca de tabelas Snowflake.
"""

import re
import requests
from typing import Generator


class QlikConnector:
    def __init__(self, tenant_url: str, api_key: str):
        self.base = tenant_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    # ------------------------------------------------------------------
    # Apps
    # ------------------------------------------------------------------

    def list_apps(self) -> list[dict]:
        """Retorna todos os apps do tenant (pagina automaticamente)."""
        apps = []
        url = f"{self.base}/api/v1/items?resourceType=app&limit=100"
        while url:
            resp = self.session.get(url)
            resp.raise_for_status()
            data = resp.json()
            apps.extend(data.get("data", []))
            # paginação via Link header ou next
            links = data.get("links", {})
            next_href = links.get("next", {}).get("href")
            url = next_href if next_href else None
        return apps

    def get_app_script(self, app_id: str) -> str | None:
        """Obtém o load script de um app. Retorna None se não conseguir."""
        url = f"{self.base}/api/v1/apps/{app_id}/script"
        resp = self.session.get(url)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        data = resp.json()
        # O script pode vir em diferentes formatos dependendo da versão da API
        if isinstance(data, str):
            return data
        return data.get("script") or data.get("qScript") or ""

    def get_app_sheets(self, app_id: str) -> list[dict]:
        """Retorna os sheets (painéis/abas) de um app."""
        url = f"{self.base}/api/v1/apps/{app_id}/objects?type=sheet"
        resp = self.session.get(url)
        if resp.status_code in (403, 404):
            return []
        resp.raise_for_status()
        return resp.json().get("data", [])

    # ------------------------------------------------------------------
    # Parsing de tabelas Snowflake no load script
    # ------------------------------------------------------------------

    @staticmethod
    def extract_snowflake_tables(script: str) -> set[str]:
        """
        Extrai referências a tabelas Snowflake de um load script Qlik.

        Identifica padrões comuns:
          - SQL SELECT FROM <db>.<schema>.<table>
          - LIB CONNECT TO ... + SELECT / FROM
          - Comentários de conexão Snowflake
        """
        if not script:
            return set()

        tables: set[str] = set()

        # Padrão: DATABASE.SCHEMA.TABLE (3 partes separadas por ponto)
        # Captura nomes que possam ter aspas duplas
        pattern_fqn = re.compile(
            r'"?([A-Z0-9_]+)"?\."?([A-Z0-9_]+)"?\."?([A-Z0-9_]+)"?',
            re.IGNORECASE,
        )

        # Padrão: FROM ou JOIN seguido de nome de tabela (1, 2 ou 3 partes)
        pattern_from = re.compile(
            r'(?:FROM|JOIN)\s+"?([A-Z0-9_]+(?:\.[A-Z0-9_]+){0,2})"?',
            re.IGNORECASE,
        )

        for match in pattern_fqn.finditer(script):
            db, schema, table = match.groups()
            # Filtra palavras-chave comuns do SQL que não são tabelas
            if not _is_keyword(db) and not _is_keyword(schema) and not _is_keyword(table):
                tables.add(f"{db.upper()}.{schema.upper()}.{table.upper()}")

        for match in pattern_from.finditer(script):
            ref = match.group(1).upper()
            parts = ref.split(".")
            if len(parts) == 3 and not any(_is_keyword(p) for p in parts):
                tables.add(ref)

        return tables

    # ------------------------------------------------------------------
    # Busca principal: qual app usa determinada tabela
    # ------------------------------------------------------------------

    def find_apps_using_table(
        self, table_fqn: str, verbose: bool = False
    ) -> list[dict]:
        """
        Varre todos os apps e retorna aqueles cujos load scripts referenciam
        a tabela informada (comparação case-insensitive).

        Retorna lista de dicts com: app_id, app_name, matched_table, sheets.
        """
        target = table_fqn.upper()
        results = []

        apps = self.list_apps()
        if verbose:
            print(f"  [Qlik] {len(apps)} app(s) encontrado(s) no tenant.")

        for app in apps:
            app_id = app.get("resourceId") or app.get("id")
            app_name = app.get("name", "sem nome")

            if verbose:
                print(f"  [Qlik] Analisando: {app_name} ({app_id})")

            script = self.get_app_script(app_id)
            if not script:
                continue

            tables_in_script = self.extract_snowflake_tables(script)

            # Verifica se alguma tabela do script corresponde ao alvo
            # (aceita match parcial: TABLE ou SCHEMA.TABLE ou DB.SCHEMA.TABLE)
            for t in tables_in_script:
                if t == target or t.endswith(f".{target}") or target.endswith(f".{t}"):
                    sheets = self.get_app_sheets(app_id)
                    results.append({
                        "app_id": app_id,
                        "app_name": app_name,
                        "matched_table": t,
                        "sheets": [
                            {"id": s.get("id"), "name": s.get("name", "")}
                            for s in sheets
                        ],
                    })
                    break  # já encontrou, não precisa checar outras tabelas deste app

        return results


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

_SQL_KEYWORDS = {
    "SELECT", "FROM", "WHERE", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER",
    "ON", "AND", "OR", "NOT", "IN", "IS", "NULL", "AS", "BY", "GROUP",
    "ORDER", "HAVING", "LIMIT", "UNION", "ALL", "DISTINCT", "CASE", "WHEN",
    "THEN", "ELSE", "END", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP",
    "ALTER", "TABLE", "VIEW", "WITH", "SET", "VALUES", "INTO",
    "INFORMATION_SCHEMA", "SHOW", "DESC", "DESCRIBE",
}


def _is_keyword(word: str) -> bool:
    return word.upper() in _SQL_KEYWORDS
