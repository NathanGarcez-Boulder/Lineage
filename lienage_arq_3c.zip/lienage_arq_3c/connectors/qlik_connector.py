"""
Conector Qlik Cloud.
Busca apps/dashboards que utilizam uma tabela/dataset Snowflake.
"""

import requests
from typing import Optional


class QlikConnector:
    def __init__(self, tenant_url: str, api_key: str):
        self.tenant_url = tenant_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self.tenant_url}{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Apps
    # ------------------------------------------------------------------

    def list_apps(self) -> list[dict]:
        """Lista todos os apps do tenant."""
        result = self._get("/api/v1/apps", params={"limit": 200})
        return result.get("data", [])

    def get_app_data_model(self, app_id: str) -> dict:
        """
        Retorna o modelo de dados do app via Engine API (WebSocket).
        Para uso via REST, usa o endpoint de metadata.
        """
        try:
            result = self._get(f"/api/v1/apps/{app_id}/datamodel/metadata")
            return result
        except Exception:
            return {}

    def get_app_connections(self, app_id: str) -> list[dict]:
        """Retorna as conexões de dados configuradas no app."""
        try:
            result = self._get(f"/api/v1/apps/{app_id}/connections")
            return result.get("data", [])
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Datasets / Spaces
    # ------------------------------------------------------------------

    def list_datasets(self) -> list[dict]:
        """Lista datasets catalogados no Qlik Cloud."""
        try:
            result = self._get("/api/v1/datasets", params={"limit": 200})
            return result.get("data", [])
        except Exception:
            return []

    def find_datasets_for_table(self, table_name: str) -> list[dict]:
        """Busca datasets que referenciam a tabela."""
        datasets = self.list_datasets()
        matches = []
        table_upper = table_name.upper()
        for ds in datasets:
            name = (ds.get("name") or "").upper()
            operational_data = str(ds).upper()
            if table_upper in name or table_upper in operational_data:
                matches.append(ds)
        return matches

    # ------------------------------------------------------------------
    # Busca de apps por tabela
    # ------------------------------------------------------------------

    def find_apps_using_table(self, table_name: str) -> list[dict]:
        """
        Estratégia principal: verifica conexões e metadata de cada app.
        Retorna lista de apps que referenciam a tabela.
        """
        apps = self.list_apps()
        matches = []
        table_upper = table_name.upper()

        for app in apps:
            app_id = app.get("attributes", {}).get("id") or app.get("id")
            if not app_id:
                continue

            # Verifica nas conexões
            connections = self.get_app_connections(app_id)
            for conn in connections:
                conn_str = str(conn).upper()
                if table_upper in conn_str:
                    matches.append({
                        "app_id": app_id,
                        "app_name": app.get("attributes", {}).get("name") or app.get("name"),
                        "space_id": app.get("attributes", {}).get("spaceId"),
                        "match_source": "connection",
                        "connection_detail": conn,
                    })
                    break

        return matches

    def get_app_sheets(self, app_id: str) -> list[dict]:
        """Lista sheets (painéis) de um app."""
        try:
            result = self._get(f"/api/v1/apps/{app_id}/sheets")
            return result.get("data", [])
        except Exception:
            return []
