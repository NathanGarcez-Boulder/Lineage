"""
Conector Qlik Cloud.
Busca apps/dashboards que utilizam uma tabela/dataset Snowflake.
"""

import requests
from typing import Optional


class QlikConnector:
    def __init__(self, tenant_url: str, api_key: str):
        self.tenant_url = tenant_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{self.tenant_url}{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Apps
    # ------------------------------------------------------------------

    def list_apps(self) -> list[dict]:
        """Lista todos os apps do tenant."""
        result = self._get("/api/v1/apps", params={"limit": 200})
        return result.get("data", [])

    def get_app_data_model(self, app_id: str) -> dict:
        """
        Retorna o modelo de dados do app via Engine API (WebSocket).
        Para uso via REST, usa o endpoint de metadata.
        """
        try:
            result = self._get(f"/api/v1/apps/{app_id}/datamodel/metadata")
            return result
        except Exception:
            return {}

    def get_app_connections(self, app_id: str) -> list[dict]:
        """Retorna as conexões de dados configuradas no app."""
        try:
            result = self._get(f"/api/v1/apps/{app_id}/connections")
            return result.get("data", [])
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Datasets / Spaces
    # ------------------------------------------------------------------

    def list_datasets(self) -> list[dict]:
        """Lista datasets catalogados no Qlik Cloud."""
        try:
            result = self._get("/api/v1/datasets", params={"limit": 200})
            return result.get("data", [])
        except Exception:
            return []

    def find_datasets_for_table(self, table_name: str) -> list[dict]:
        """Busca datasets que referenciam a tabela."""
        datasets = self.list_datasets()
        matches = []
        table_upper = table_name.upper()
        for ds in datasets:
            name = (ds.get("name") or "").upper()
            operational_data = str(ds).upper()
            if table_upper in name or table_upper in operational_data:
                matches.append(ds)
        return matches

    # ------------------------------------------------------------------
    # Busca de apps por tabela
    # ------------------------------------------------------------------

    def find_apps_using_table(self, table_name: str) -> list[dict]:
        """
        Estratégia principal: verifica conexões e metadata de cada app.
        Retorna lista de apps que referenciam a tabela.
        """
        apps = self.list_apps()
        matches = []
        table_upper = table_name.upper()

        for app in apps:
            app_id = app.get("attributes", {}).get("id") or app.get("id")
            if not app_id:
                continue

            # Verifica nas conexões
            connections = self.get_app_connections(app_id)
            for conn in connections:
                conn_str = str(conn).upper()
                if table_upper in conn_str:
                    matches.append({
                        "app_id": app_id,
                        "app_name": app.get("attributes", {}).get("name") or app.get("name"),
                        "space_id": app.get("attributes", {}).get("spaceId"),
                        "match_source": "connection",
                        "connection_detail": conn,
                    })
                    break

        return matches

    def get_app_sheets(self, app_id: str) -> list[dict]:
        """Lista sheets (painéis) de um app."""
        try:
            result = self._get(f"/api/v1/apps/{app_id}/sheets")
            return result.get("data", [])
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Load script
    # ------------------------------------------------------------------

    def get_app_script(self, app_id: str) -> str:
        """
        Retorna o load script completo do app.
        Endpoint: GET /api/v1/apps/{appId}/scripts
        Resposta pode ser lista de seções ou objeto com campo 'script'.
        """
        try:
            result = self._get(f"/api/v1/apps/{app_id}/scripts")
            if isinstance(result, list):
                return "\n".join(s.get("scriptText", "") for s in result)
            if isinstance(result, dict):
                return result.get("script", result.get("scriptText", ""))
            return ""
        except Exception:
            return ""

    def list_apps_all(self) -> list[dict]:
        """
        Lista todos os apps do tenant com paginação completa.
        Usa /api/v1/items?resourceType=app que suporta cursor pagination.
        """
        apps = []
        params: dict = {"resourceType": "app", "limit": 100}
        while True:
            try:
                resp = self._get("/api/v1/items", params=params)
            except Exception:
                break
            data = resp.get("data", [])
            apps.extend(data)
            next_cursor = (
                resp.get("links", {}).get("next", {}).get("href", "")
            )
            if not data or not next_cursor:
                break
            # extrai parâmetro cursor da URL de próxima página
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(next_cursor).query)
            cursor = qs.get("next", [None])[0]
            if not cursor:
                break
            params = {"resourceType": "app", "limit": 100, "next": cursor}
        return apps

    def get_space_name(self, space_id: str) -> str:
        """Retorna o nome do space pelo ID."""
        if not space_id:
            return ""
        try:
            result = self._get(f"/api/v1/spaces/{space_id}")
            return result.get("name", "")
        except Exception:
            return ""
