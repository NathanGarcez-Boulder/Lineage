"""
Orchestrador de linhagem.
Dado um nome de tabela Snowflake, busca em todos os sistemas
e cria a linhagem no OpenMetadata automaticamente.
"""

import logging
from dataclasses import dataclass, field

from connectors.openmetadata_client import OpenMetadataClient
from connectors.snowflake_connector import SnowflakeConnector
from connectors.informatica_connector import InformaticaConnector
from connectors.airflow_connector import AirflowConnector
from connectors.qlik_connector import QlikConnector

logger = logging.getLogger(__name__)


@dataclass
class LineageResult:
    table_fqn: str
    informatica_tasks: list = field(default_factory=list)
    airflow_dags: list = field(default_factory=list)
    qlik_apps: list = field(default_factory=list)
    lineage_edges_created: list = field(default_factory=list)
    errors: list = field(default_factory=list)


class LineageBuilder:
    def __init__(self, config: dict):
        self.cfg = config
        self.om_cfg = config["openmetadata"]
        self.sf_cfg = config["snowflake"]
        self.iics_cfg = config["informatica"]
        self.airflow_cfg = config["airflow"]
        self.qlik_cfg = config["qlik"]
        self.lineage_cfg = config["lineage"]

        self.om = OpenMetadataClient(
            host=self.om_cfg["host"],
            jwt_token=self.om_cfg["jwt_token"],
        )

    def build_lineage_for_table(self, schema: str, table: str) -> LineageResult:
        """
        Ponto de entrada principal.
        Recebe schema e nome da tabela Snowflake e constrói toda a linhagem.
        """
        sf_service = self.lineage_cfg["snowflake_service_name"]
        sf_db = self.sf_cfg["database"]
        table_fqn = f"{sf_service}.{sf_db}.{schema}.{table}"

        logger.info(f"Iniciando linhagem para: {table_fqn}")
        result = LineageResult(table_fqn=table_fqn)

        # 1. Verifica se a tabela existe no OpenMetadata
        table_entity = self.om.get_table(table_fqn)
        if not table_entity:
            msg = f"Tabela não encontrada no OpenMetadata: {table_fqn}"
            logger.warning(msg)
            result.errors.append(msg)
            # Não para — tenta criar linhagem mesmo assim (entidade pode ser criada depois)

        # 2. Busca ETL no Informatica Cloud
        result.informatica_tasks = self._find_informatica_tasks(table, result)

        # 3. Busca ETL no Airflow
        result.airflow_dags = self._find_airflow_dags(table, result)

        # 4. Busca dashboards no Qlik Cloud
        result.qlik_apps = self._find_qlik_apps(table, result)

        # 5. Cria arestas de linhagem no OpenMetadata
        self._create_lineage_edges(table_fqn, result)

        return result

    # ------------------------------------------------------------------
    # Informatica
    # ------------------------------------------------------------------

    def _find_informatica_tasks(self, table: str, result: LineageResult) -> list:
        logger.info("Buscando tasks no Informatica Cloud...")
        try:
            with InformaticaConnector(
                base_url=self.iics_cfg["base_url"],
                username=self.iics_cfg["username"],
                password=self.iics_cfg["password"],
                org_id=self.iics_cfg["org_id"],
            ) as iics:
                tasks = iics.find_tasks_writing_to_table(table)
                logger.info(f"  → {len(tasks)} task(s) encontrada(s) no Informatica")
                return tasks
        except Exception as e:
            msg = f"Erro ao consultar Informatica: {e}"
            logger.error(msg)
            result.errors.append(msg)
            return []

    # ------------------------------------------------------------------
    # Airflow
    # ------------------------------------------------------------------

    def _find_airflow_dags(self, table: str, result: LineageResult) -> list:
        logger.info("Buscando DAGs no Airflow...")
        try:
            af = AirflowConnector(
                base_url=self.airflow_cfg["base_url"],
                username=self.airflow_cfg["username"],
                password=self.airflow_cfg["password"],
            )
            dags = af.find_dags_referencing_table(table)
            logger.info(f"  → {len(dags)} DAG(s) encontrada(s) no Airflow")
            return dags
        except Exception as e:
            msg = f"Erro ao consultar Airflow: {e}"
            logger.error(msg)
            result.errors.append(msg)
            return []

    # ------------------------------------------------------------------
    # Qlik
    # ------------------------------------------------------------------

    def _find_qlik_apps(self, table: str, result: LineageResult) -> list:
        logger.info("Buscando apps no Qlik Cloud...")
        try:
            qlik = QlikConnector(
                tenant_url=self.qlik_cfg["tenant_url"],
                api_key=self.qlik_cfg["api_key"],
            )
            apps = qlik.find_apps_using_table(table)
            logger.info(f"  → {len(apps)} app(s) encontrado(s) no Qlik")
            return apps
        except Exception as e:
            msg = f"Erro ao consultar Qlik Cloud: {e}"
            logger.error(msg)
            result.errors.append(msg)
            return []

    # ------------------------------------------------------------------
    # Criação de linhagem no OpenMetadata
    # ------------------------------------------------------------------

    def _create_lineage_edges(self, table_fqn: str, result: LineageResult):
        logger.info("Criando arestas de linhagem no OpenMetadata...")

        iics_service = self.lineage_cfg["informatica_service_name"]
        af_service = self.lineage_cfg["airflow_service_name"]
        qlik_service = self.lineage_cfg["qlik_service_name"]

        # Informatica → Tabela Snowflake
        for task in result.informatica_tasks:
            task_name = task.get("task_name", "")
            pipeline_fqn = f"{iics_service}.{task_name}"
            try:
                self.om.add_lineage(
                    from_entity_type="pipeline",
                    from_fqn=pipeline_fqn,
                    to_entity_type="table",
                    to_fqn=table_fqn,
                    description=f"ETL Informatica Cloud: {task_name}",
                )
                edge = f"PIPELINE({pipeline_fqn}) → TABLE({table_fqn})"
                result.lineage_edges_created.append(edge)
                logger.info(f"  ✓ {edge}")
            except Exception as e:
                msg = f"Erro ao criar linhagem Informatica→Tabela ({pipeline_fqn}): {e}"
                logger.error(msg)
                result.errors.append(msg)

        # Airflow DAG → Tabela Snowflake
        for dag in result.airflow_dags:
            dag_id = dag.get("dag_id", "")
            pipeline_fqn = f"{af_service}.{dag_id}"
            try:
                self.om.add_lineage(
                    from_entity_type="pipeline",
                    from_fqn=pipeline_fqn,
                    to_entity_type="table",
                    to_fqn=table_fqn,
                    description=f"DAG Airflow: {dag_id}",
                )
                edge = f"PIPELINE({pipeline_fqn}) → TABLE({table_fqn})"
                result.lineage_edges_created.append(edge)
                logger.info(f"  ✓ {edge}")
            except Exception as e:
                msg = f"Erro ao criar linhagem Airflow→Tabela ({pipeline_fqn}): {e}"
                logger.error(msg)
                result.errors.append(msg)

        # Tabela Snowflake → Qlik App
        for app in result.qlik_apps:
            app_name = app.get("app_name", "")
            dashboard_fqn = f"{qlik_service}.{app_name}"
            try:
                self.om.add_lineage(
                    from_entity_type="table",
                    from_fqn=table_fqn,
                    to_entity_type="dashboard",
                    to_fqn=dashboard_fqn,
                    description=f"Dashboard Qlik Cloud: {app_name}",
                )
                edge = f"TABLE({table_fqn}) → DASHBOARD({dashboard_fqn})"
                result.lineage_edges_created.append(edge)
                logger.info(f"  ✓ {edge}")
            except Exception as e:
                msg = f"Erro ao criar linhagem Tabela→Qlik ({dashboard_fqn}): {e}"
                logger.error(msg)
                result.errors.append(msg)
