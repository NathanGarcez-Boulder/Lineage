from om_client import OpenMetadataClient


class LineageBuilder:
    def __init__(self):
        self.client = OpenMetadataClient()

    def _print_entity(self, label, entities):
        if not entities:
            print(f"  {label}: nenhum encontrado")
            return
        for e in entities:
            print(f"  [{label}] {e.get('fullyQualifiedName', e.get('name', '?'))} (id: {e.get('id', '?')})")

    def explore(self, table_name):
        """
        Dado um nome de tabela Snowflake, exibe o que foi encontrado
        no OpenMetadata: tabela, pipelines relacionados e dashboards.
        """
        print(f"\n=== Explorando: {table_name} ===\n")

        # 1. Buscar a tabela
        tables = self.client.get_table_by_name(table_name)
        print(f"Tabelas encontradas ({len(tables)}):")
        self._print_entity("tabela", tables)

        if not tables:
            print("\nTabela não encontrada. Verifique o nome e tente novamente.")
            return None, [], []

        # Se encontrou mais de uma, usa a primeira
        table = tables[0]
        print(f"\nUsando: {table.get('fullyQualifiedName')}")

        # 2. Linhagem já existente
        print("\nLinhagem existente no OpenMetadata:")
        try:
            lineage = self.client.get_lineage("table", table["id"])
            nodes = lineage.get("nodes", [])
            edges = lineage.get("edges", [])
            if edges:
                for edge in edges:
                    print(f"  {edge.get('fromEntity', {}).get('fqn', '?')} → {edge.get('toEntity', {}).get('fqn', '?')}")
            else:
                print("  Nenhuma linhagem registrada ainda.")
        except Exception as e:
            print(f"  Erro ao buscar linhagem: {e}")

        # 3. Buscar pipelines com o nome da tabela
        table_short = table_name.split(".")[-1]  # pega só o nome da tabela sem schema
        print(f"\nPipelines relacionados a '{table_short}':")
        pipelines = self.client.get_pipelines_by_name(table_short)
        self._print_entity("pipeline", pipelines)

        # 4. Buscar dashboards com o nome da tabela
        print(f"\nDashboards relacionados a '{table_short}':")
        dashboards = self.client.get_dashboards_by_name(table_short)
        self._print_entity("dashboard", dashboards)

        return table, pipelines, dashboards

    def build(self, table_name, pipeline_name=None, dashboard_name=None):
        """
        Constrói a linhagem: Pipeline → Tabela → Dashboard.

        Se pipeline_name ou dashboard_name forem None, tenta descobrir automaticamente.
        """
        table, auto_pipelines, auto_dashboards = self.explore(table_name)

        if not table:
            return

        table_id = table["id"]
        created = []

        # --- Pipeline → Tabela ---
        pipelines_to_link = []
        if pipeline_name:
            results = self.client.get_pipelines_by_name(pipeline_name)
            if results:
                pipelines_to_link = [results[0]]
            else:
                print(f"\nPipeline '{pipeline_name}' não encontrado.")
        else:
            pipelines_to_link = auto_pipelines

        for pipeline in pipelines_to_link:
            pid = pipeline["id"]
            pfqn = pipeline.get("fullyQualifiedName", pipeline.get("name"))
            try:
                self.client.add_lineage_edge(pid, "pipeline", table_id, "table")
                print(f"\n[OK] Linhagem criada: {pfqn} → {table.get('fullyQualifiedName')}")
                created.append((pfqn, table.get("fullyQualifiedName")))
            except Exception as e:
                print(f"\n[ERRO] Pipeline → Tabela: {e}")

        # --- Tabela → Dashboard ---
        dashboards_to_link = []
        if dashboard_name:
            results = self.client.get_dashboards_by_name(dashboard_name)
            if results:
                dashboards_to_link = [results[0]]
            else:
                print(f"\nDashboard '{dashboard_name}' não encontrado.")
        else:
            dashboards_to_link = auto_dashboards

        for dashboard in dashboards_to_link:
            did = dashboard["id"]
            dfqn = dashboard.get("fullyQualifiedName", dashboard.get("name"))
            try:
                self.client.add_lineage_edge(table_id, "table", did, "dashboard")
                print(f"[OK] Linhagem criada: {table.get('fullyQualifiedName')} → {dfqn}")
                created.append((table.get("fullyQualifiedName"), dfqn))
            except Exception as e:
                print(f"\n[ERRO] Tabela → Dashboard: {e}")

        print(f"\nTotal de edges criadas: {len(created)}")
        return created
