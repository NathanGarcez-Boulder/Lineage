"""
Orquestrador principal: dado uma tabela Snowflake, encontra os painéis Qlik
que a utilizam e registra a linhagem no OpenMetadata.
"""

from __future__ import annotations

import yaml
from pathlib import Path

from connectors.snowflake_connector import get_connection, validate_table
from connectors.qlik_connector import QlikConnector
from connectors.openmetadata_client import OpenMetadataClient


def load_config(path: str = "config/settings.yaml") -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def run(
    table_fqn: str,
    dry_run: bool = False,
    verbose: bool = False,
    config_path: str = "config/settings.yaml",
) -> None:
    """
    Fluxo principal:
    1. Valida a tabela no Snowflake (key pair auth)
    2. Varre apps Qlik buscando referências à tabela
    3. Registra linhagem Tabela → Dashboard no OpenMetadata
    """
    cfg = load_config(config_path)

    # ---- 1. Snowflake: valida tabela ----
    print(f"\n[Snowflake] Validando tabela: {table_fqn}")
    conn = get_connection(cfg["snowflake"])
    table_meta = validate_table(conn, table_fqn)
    conn.close()

    if not table_meta:
        print(f"[ERRO] Tabela '{table_fqn}' não encontrada no Snowflake.")
        return

    print(f"[Snowflake] Tabela encontrada: {table_meta['fqn']} "
          f"(tipo: {table_meta['type']}, linhas: {table_meta['rows']:,})")

    # ---- 2. Qlik: busca apps que usam a tabela ----
    print(f"\n[Qlik] Buscando apps que referenciam '{table_meta['fqn']}'...")
    qlik = QlikConnector(
        tenant_url=cfg["qlik"]["tenant_url"],
        api_key=cfg["qlik"]["api_key"],
    )
    matches = qlik.find_apps_using_table(table_meta["fqn"], verbose=verbose)

    if not matches:
        print("[Qlik] Nenhum app encontrado que referencie esta tabela.")
        return

    print(f"[Qlik] {len(matches)} app(s) encontrado(s):")
    for m in matches:
        sheets_info = ", ".join(s["name"] for s in m["sheets"] if s["name"]) or "sem sheets"
        print(f"  - {m['app_name']} (ID: {m['app_id']})")
        print(f"    Tabela no script: {m['matched_table']}")
        print(f"    Sheets: {sheets_info}")

    # ---- 3. OpenMetadata: registra linhagem ----
    print(f"\n[OpenMetadata] {'[DRY-RUN] ' if dry_run else ''}Registrando linhagem...")
    om = OpenMetadataClient(
        host=cfg["openmetadata"]["host"],
        jwt_token=cfg["openmetadata"]["jwt_token"],
    )
    sf_service = cfg["openmetadata"]["snowflake_service_name"]
    qlik_service = cfg["openmetadata"]["qlik_service_name"]

    table_entity = om.get_table_entity(sf_service, table_meta["fqn"])
    if not table_entity:
        print(f"[AVISO] Tabela '{table_meta['fqn']}' não encontrada no OpenMetadata. "
              "Verifique se o conector Snowflake já ingeriu os metadados.")
        return

    created = 0
    skipped = 0

    for match in matches:
        dashboard_entity = om.get_dashboard_entity(qlik_service, match["app_name"])
        if not dashboard_entity:
            print(f"  [AVISO] Dashboard '{match['app_name']}' não encontrado no OpenMetadata. Pulando.")
            skipped += 1
            continue

        edge_desc = f"Tabela Snowflake usada no load script do app Qlik '{match['app_name']}'"

        if dry_run:
            print(f"  [DRY-RUN] Criaria: {table_entity['fullyQualifiedName']} → "
                  f"{dashboard_entity['fullyQualifiedName']}")
        else:
            ok = om.create_lineage_edge(
                from_entity=table_entity,
                from_type="table",
                to_entity=dashboard_entity,
                to_type="dashboard",
                description=edge_desc,
            )
            if ok:
                print(f"  [OK] {table_entity['fullyQualifiedName']} → "
                      f"{dashboard_entity['fullyQualifiedName']}")
                created += 1
            else:
                print(f"  [FALHA] Não foi possível criar linhagem para '{match['app_name']}'.")
                skipped += 1

    if not dry_run:
        print(f"\n[Resumo] {created} linhagem(ns) criada(s), {skipped} pulada(s).")
    else:
        print(f"\n[Resumo DRY-RUN] {len(matches)} linhagem(ns) seria(m) criada(s).")
