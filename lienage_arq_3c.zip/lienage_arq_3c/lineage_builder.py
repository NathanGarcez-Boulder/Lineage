"""
Orquestrador de linhagem Snowflake → Qlik Cloud via OpenMetadata.

Fluxo:
  1. Lista todos os apps Qlik via API REST
  2. Extrai load script de cada app e parseia referências a tabelas Snowflake
  3. Resolve cada (app, tabela) nas entidades já existentes no OpenMetadata
  4. Cria as arestas de linhagem: Tabela Snowflake → Dashboard Qlik

Pré-requisito: os conectores Snowflake e Qlik já devem estar ingerindo
               metadados no OpenMetadata (tabelas e dashboards já existem).
"""

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    import sqlglot
    from sqlglot import exp as sqlglot_exp
    _HAS_SQLGLOT = True
except ImportError:
    _HAS_SQLGLOT = False

from connectors.openmetadata_client import OpenMetadataClient
from connectors.qlik_connector import QlikConnector

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Parser SQL — extração de tabelas do load script Qlik
# ---------------------------------------------------------------------------

_SKIP_NAMES = frozenset({
    "DUAL", "LATERAL", "VALUES", "UNNEST", "GENERATOR",
    "TABLE", "SELECT", "WHERE", "SET", "INFORMATION_SCHEMA",
    "RESULT", "TEMP", "TMP",
})

_TABLE_RE = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'(?:"?(\w+)"?\.)?'
    r'(?:"?(\w+)"?\.)?'
    r'"?(\w+)"?'
    r'(?:\s|$|,|\(|;)',
    re.IGNORECASE,
)

_QLIK_SQL_RE = re.compile(
    r'\bSQL\s+(SELECT\b.+?)(?=;|\bLOAD\b|\bSQL\b|\Z)',
    re.IGNORECASE | re.DOTALL,
)

_LIB_RE = re.compile(
    r'FROM\s+\[lib://[^/:\]]+(?::[^/\]]+)?/([^/\]]+)/([^/\]]+)/([^\]]+)\]',
    re.IGNORECASE,
)


def _extract_tables_sqlglot(sql: str) -> list[dict]:
    tables = []
    try:
        for stmt in sqlglot.parse(sql, dialect="snowflake",
                                   error_level=sqlglot.ErrorLevel.IGNORE):
            if stmt is None:
                continue
            for tbl in stmt.find_all(sqlglot_exp.Table):
                name = (tbl.name or "").upper()
                if not name or name in _SKIP_NAMES:
                    continue
                tables.append({
                    "table": name,
                    "schema": (tbl.db or "").upper() or None,
                    "database": (tbl.catalog or "").upper() or None,
                })
    except Exception:
        pass
    return tables


def _extract_tables_regex(sql: str) -> list[dict]:
    tables = []
    for m in _TABLE_RE.finditer(sql):
        name = (m.group(3) or "").upper()
        if not name or name in _SKIP_NAMES:
            continue
        tables.append({
            "table": name,
            "schema": (m.group(2) or "").upper() or None,
            "database": (m.group(1) or "").upper() or None,
        })
    return tables


def _extract_sql_tables(sql: str) -> list[dict]:
    if _HAS_SQLGLOT:
        result = _extract_tables_sqlglot(sql)
        if result:
            return result
    return _extract_tables_regex(sql)


def extract_tables_from_qlik_script(script: str) -> list[dict]:
    """
    Extrai referências de tabelas Snowflake de um load script Qlik.
    Cobre dois padrões:
      - SQL SELECT ... FROM db.schema.table;
      - LOAD * FROM [lib://Conn:DB/SCHEMA/TABLE];
    """
    tables = []

    for m in _QLIK_SQL_RE.finditer(script):
        tables.extend(_extract_sql_tables(m.group(1)))

    for m in _LIB_RE.finditer(script):
        tables.append({
            "database": m.group(1).upper(),
            "schema": m.group(2).upper(),
            "table": m.group(3).upper(),
        })

    # Deduplica mantendo ordem
    seen = set()
    unique = []
    for t in tables:
        key = (t.get("database"), t.get("schema"), t["table"])
        if key not in seen:
            seen.add(key)
            unique.append(t)
    return unique


# ---------------------------------------------------------------------------
# Resultado
# ---------------------------------------------------------------------------

@dataclass
class EdgeResult:
    table_fqn: str
    dashboard_fqn: str
    status: str          # "created" | "skipped" | "error"
    message: str = ""


@dataclass
class AppResult:
    app_id: str
    app_name: str
    tables_found: int = 0
    edges: list[EdgeResult] = field(default_factory=list)

    @property
    def created(self) -> int:
        return sum(1 for e in self.edges if e.status == "created")

    @property
    def skipped(self) -> int:
        return sum(1 for e in self.edges if e.status == "skipped")

    @property
    def errors(self) -> int:
        return sum(1 for e in self.edges if e.status == "error")


@dataclass
class LineageRunResult:
    apps_processed: int = 0
    apps_with_script: int = 0
    total_edges_created: int = 0
    total_edges_skipped: int = 0
    total_errors: int = 0
    app_results: list[AppResult] = field(default_factory=list)
    global_errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Builder principal
# ---------------------------------------------------------------------------

class LineageBuilder:
    def __init__(self, config: dict):
        self.cfg = config
        self.sf_cfg = config["snowflake"]
        self.qlik_cfg = config["qlik"]
        self.lineage_cfg = config["lineage"]

        self.om = OpenMetadataClient(
            host=config["openmetadata"]["host"],
            jwt_token=config["openmetadata"]["jwt_token"],
        )
        self.qlik = QlikConnector(
            tenant_url=self.qlik_cfg["tenant_url"],
            api_key=self.qlik_cfg["api_key"],
        )

        # Cache: nome normalizado → entidade OpenMetadata
        self._dashboard_cache: dict[str, dict] = {}
        self._table_cache: dict[str, Optional[dict]] = {}

    # ------------------------------------------------------------------
    # Ponto de entrada
    # ------------------------------------------------------------------

    def run(self, app_name_filter: str = None, dry_run: bool = False) -> LineageRunResult:
        """
        Executa a automação de linhagem.

        app_name_filter: se informado, processa apenas o app com esse nome.
        dry_run: exibe o que seria criado sem alterar o OpenMetadata.
        """
        result = LineageRunResult()

        if not _HAS_SQLGLOT:
            log.warning(
                "sqlglot não instalado — usando parser regex (menos preciso). "
                "Instale com: pip install sqlglot"
            )

        # 1. Carrega index de dashboards do OpenMetadata
        log.info("Carregando dashboards do OpenMetadata...")
        self._load_dashboard_cache()
        log.info(f"  → {len(self._dashboard_cache)} dashboard(s) encontrado(s) no OpenMetadata.")

        # 2. Lista apps Qlik
        log.info("Listando apps Qlik Cloud...")
        apps = self.qlik.list_apps_all() or self.qlik.list_apps()
        log.info(f"  → {len(apps)} app(s) encontrado(s) no Qlik.")

        if app_name_filter:
            apps = [a for a in apps if app_name_filter.lower() in self._app_name(a).lower()]
            log.info(f"  → Filtrado para {len(apps)} app(s) com nome contendo '{app_name_filter}'.")

        result.apps_processed = len(apps)

        # 3. Processa cada app
        for app in apps:
            app_result = self._process_app(app, dry_run=dry_run)
            result.app_results.append(app_result)
            if app_result.tables_found > 0:
                result.apps_with_script += 1
            result.total_edges_created += app_result.created
            result.total_edges_skipped += app_result.skipped
            result.total_errors += app_result.errors

        return result

    # ------------------------------------------------------------------
    # Processamento de um app
    # ------------------------------------------------------------------

    def _process_app(self, app: dict, dry_run: bool) -> AppResult:
        app_id = self._app_id(app)
        app_name = self._app_name(app)
        app_result = AppResult(app_id=app_id, app_name=app_name)

        log.info(f"\n{'─' * 50}")
        log.info(f"App: {app_name} ({app_id})")

        # Resolve dashboard no OpenMetadata
        dashboard_entity = self._resolve_dashboard(app_name)
        if not dashboard_entity:
            log.warning(f"  ⚠ Dashboard '{app_name}' não encontrado no OpenMetadata. Ignorando app.")
            app_result.edges.append(EdgeResult(
                table_fqn="", dashboard_fqn=app_name,
                status="skipped",
                message="Dashboard não encontrado no OpenMetadata",
            ))
            return app_result

        dashboard_fqn = dashboard_entity.get("fullyQualifiedName", app_name)
        log.info(f"  ✓ Dashboard OpenMetadata: {dashboard_fqn}")

        # Obtém e parseia load script
        script = self.qlik.get_app_script(app_id)
        if not script:
            log.warning(f"  ⚠ Load script vazio ou inacessível.")
            return app_result

        table_refs = extract_tables_from_qlik_script(script)
        app_result.tables_found = len(table_refs)
        log.info(f"  → {len(table_refs)} referência(s) de tabela no script.")

        # Cria arestas para cada tabela encontrada
        for ref in table_refs:
            edge = self._process_table_ref(
                ref=ref,
                dashboard_entity=dashboard_entity,
                dashboard_fqn=dashboard_fqn,
                dry_run=dry_run,
            )
            app_result.edges.append(edge)

        return app_result

    # ------------------------------------------------------------------
    # Processamento de uma referência de tabela
    # ------------------------------------------------------------------

    def _process_table_ref(
        self,
        ref: dict,
        dashboard_entity: dict,
        dashboard_fqn: str,
        dry_run: bool,
    ) -> EdgeResult:
        table_fqn = self._build_table_fqn(ref)

        table_entity = self._resolve_table(table_fqn)
        if not table_entity:
            log.debug(f"    Tabela não encontrada no OpenMetadata: {table_fqn}")
            return EdgeResult(
                table_fqn=table_fqn,
                dashboard_fqn=dashboard_fqn,
                status="skipped",
                message="Tabela não encontrada no OpenMetadata",
            )

        action = "[DRY-RUN] Criaria" if dry_run else "Criando"
        log.info(f"    {action} linhagem: {table_fqn} → {dashboard_fqn}")

        if dry_run:
            return EdgeResult(
                table_fqn=table_fqn,
                dashboard_fqn=dashboard_fqn,
                status="created",
                message="dry-run",
            )

        try:
            self.om.add_lineage(
                from_entity_type="table",
                from_id=table_entity["id"],
                to_entity_type="dashboard",
                to_id=dashboard_entity["id"],
                description=f"Linhagem automática: tabela Snowflake consumida pelo app Qlik",
                source="DashboardLineage",
            )
            return EdgeResult(
                table_fqn=table_fqn,
                dashboard_fqn=dashboard_fqn,
                status="created",
            )
        except Exception as e:
            log.error(f"    ✗ Erro ao criar linhagem: {e}")
            return EdgeResult(
                table_fqn=table_fqn,
                dashboard_fqn=dashboard_fqn,
                status="error",
                message=str(e),
            )

    # ------------------------------------------------------------------
    # Resolução de entidades
    # ------------------------------------------------------------------

    def _load_dashboard_cache(self):
        """
        Carrega todos os dashboards do serviço Qlik do OpenMetadata
        e indexa por nome normalizado para lookup rápido.
        """
        service = self.lineage_cfg["qlik_service_name"]
        dashboards = self.om.list_dashboards(service)
        for d in dashboards:
            name = d.get("displayName") or d.get("name") or ""
            self._dashboard_cache[self._normalize(name)] = d

    def _resolve_dashboard(self, app_name: str) -> Optional[dict]:
        """
        Encontra o dashboard no OpenMetadata pelo nome do app Qlik.
        Tenta match exato primeiro, depois busca por nome parcial.
        """
        key = self._normalize(app_name)

        # 1. Match exato no cache
        if key in self._dashboard_cache:
            return self._dashboard_cache[key]

        # 2. Match parcial no cache (app_name contido no nome do dashboard ou vice-versa)
        for cached_key, entity in self._dashboard_cache.items():
            if key in cached_key or cached_key in key:
                return entity

        # 3. Busca na API do OpenMetadata
        service = self.lineage_cfg["qlik_service_name"]
        hits = self.om.search_dashboards(app_name, service=service, size=5)
        if hits:
            entity = hits[0].get("_source", hits[0])
            self._dashboard_cache[key] = entity
            return entity

        return None

    def _build_table_fqn(self, ref: dict) -> str:
        """
        Constrói o FQN completo da tabela para busca no OpenMetadata.
        Usa os defaults do config para database/schema quando não estão no script.
        """
        service = self.lineage_cfg["snowflake_service_name"]
        database = ref.get("database") or self.sf_cfg["database"]
        schema = ref.get("schema") or self.lineage_cfg.get("default_schema", "")
        table = ref["table"]
        return f"{service}.{database}.{schema}.{table}"

    def _resolve_table(self, fqn: str) -> Optional[dict]:
        """Busca tabela no OpenMetadata com cache local."""
        if fqn in self._table_cache:
            return self._table_cache[fqn]
        entity = self.om.get_table(fqn)
        self._table_cache[fqn] = entity
        return entity

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _app_id(app: dict) -> str:
        return (
            app.get("resourceId")
            or app.get("id")
            or (app.get("attributes") or {}).get("id")
            or ""
        )

    @staticmethod
    def _app_name(app: dict) -> str:
        return (
            app.get("name")
            or app.get("resourceAttributes", {}).get("name")
            or (app.get("attributes") or {}).get("name")
            or ""
        )

    @staticmethod
    def _normalize(name: str) -> str:
        """Normaliza nome para comparação: lowercase, sem espaços extras."""
        return re.sub(r'\s+', ' ', name.strip().lower())
