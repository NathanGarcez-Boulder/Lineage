from om_client import OpenMetadataClient


class LineageBuilder:
    def __init__(self):
        self.client = OpenMetadataClient()

    def _airflow_matches_table(self, pipeline, table_short):
        """Verifica se o nome do DAG Airflow contém o nome completo da tabela."""
        dag_name = pipeline.get("name", "").upper()
        return table_short.upper() in dag_name

    def _pick(self, entities, label):
        """Exibe lista numerada e retorna os itens escolhidos pelo usuário."""
        if not entities:
            print(f"  Nenhum {label} encontrado.")
            return []

        print(f"\n{label}s encontrados ({len(entities)}):")
        for i, e in enumerate(entities):
            fqn = e.get("fullyQualifiedName", e.get("name", "?"))
            display = e.get("displayName") or ""
            label_extra = f"  →  {display}" if display else ""
            print(f"  [{i}] {fqn}{label_extra}")

        print("Digite os números desejados (ex: 0,2), 'all' para todos, ou ENTER para nenhum:")
        choice = input("> ").strip()

        if not choice:
            return []
        if choice.lower() == "all":
            return entities

        selected = []
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit() and int(part) < len(entities):
                selected.append(entities[int(part)])
        return selected

    def _create_edge(self, from_entity, from_type, to_entity, to_type):
        from_fqn = from_entity.get("fullyQualifiedName", from_entity.get("name"))
        to_fqn = to_entity.get("fullyQualifiedName", to_entity.get("name"))
        try:
            self.client.add_lineage_edge(from_entity["id"], from_type, to_entity["id"], to_type)
            print(f"  [OK] {from_fqn}  →  {to_fqn}")
            return True
        except Exception as e:
            print(f"  [ERRO] {from_fqn} → {to_fqn}: {e}")
            return False

    def _print_auto(self, entities, label):
        """Exibe entidades selecionadas automaticamente."""
        print(f"\n{label}s selecionados automaticamente ({len(entities)}):")
        for e in entities:
            fqn = e.get("fullyQualifiedName", e.get("name", "?"))
            display = e.get("displayName") or ""
            label_extra = f"  →  {display}" if display else ""
            print(f"  [auto] {fqn}{label_extra}")

    def explore(self, table_name):
        """Exibe o que o OpenMetadata sabe sobre a tabela e entidades relacionadas."""
        print(f"\n=== Explorando: {table_name} ===\n")
        table_short = table_name.split(".")[-1].upper()

        tables = self.client.get_table_by_name(table_name)
        print(f"Tabelas encontradas ({len(tables)}):")
        for e in tables:
            print(f"  {e.get('fullyQualifiedName')} (id: {e.get('id')})")

        if not tables:
            return None, [], []

        exact = [t for t in tables if t.get("name", "").upper() == table_short]
        table = exact[0] if exact else tables[0]
        print(f"\nUsando: {table.get('fullyQualifiedName')}")

        print("\nLinhagem existente:")
        try:
            lineage = self.client.get_lineage("table", table["id"])
            edges = lineage.get("edges", [])
            if edges:
                for edge in edges:
                    print(f"  {edge.get('fromEntity', {}).get('fqn', '?')} → {edge.get('toEntity', {}).get('fqn', '?')}")
            else:
                print("  Nenhuma linhagem registrada ainda.")
        except Exception as e:
            print(f"  Erro: {e}")

        pipelines = self.client.get_pipelines_by_name(table_short)
        print(f"\nPipelines relacionados ({len(pipelines)}):")
        for e in pipelines:
            print(f"  {e.get('fullyQualifiedName', e.get('name'))} (id: {e.get('id')})")

        dashboards = self.client.get_dashboards_by_name(table_short)
        print(f"\nDashboards relacionados ({len(dashboards)}):")
        for e in dashboards:
            display = e.get("displayName") or ""
            label_extra = f"  →  {display}" if display else ""
            print(f"  {e.get('fullyQualifiedName', e.get('name'))}{label_extra} (id: {e.get('id')})")

        return table, pipelines, dashboards

    def build(self, table_name, pipeline_name=None, dashboard_name=None, auto=False):
        """
        Constrói linhagem completa:
          Informatica Cloud → Airflow → Snowflake Table → Qlik Dashboard

        auto=True:
          - Airflow: linka automaticamente os DAGs cujo nome contém o nome da tabela
          - Informatica e Qlik: pede confirmação manual (risco de match incorreto)
        """
        print(f"\n=== Build de linhagem: {table_name} ===")
        print(f"Modo: {'automático (Airflow) + manual (Informatica/Qlik)' if auto else 'manual'}")
        print("Fluxo: Informatica  →  Airflow  →  Snowflake  →  Qlik\n")

        table_short = table_name.split(".")[-1].upper()

        # --- 1. Resolve tabela Snowflake ---
        tables = self.client.get_table_by_name(table_name)
        exact = [t for t in tables if t.get("name", "").upper() == table_short]
        if not exact:
            print(f"Tabela '{table_name}' não encontrada no OpenMetadata.")
            return
        table = exact[0]
        print(f"Tabela alvo: {table.get('fullyQualifiedName')}\n")

        # --- 2. Busca pipelines ---
        search_term = pipeline_name if pipeline_name else table_short
        all_pipelines = self.client.get_pipelines_by_name(search_term)

        informatica = [p for p in all_pipelines if "informatica" in p.get("fullyQualifiedName", "").lower()]
        airflow = [p for p in all_pipelines if "airflow" in p.get("fullyQualifiedName", "").lower()]

        # --- 3. Informatica: sempre manual ---
        print("─" * 50)
        print("ETAPA 1 — Pipelines Informatica Cloud (upstream)")
        informatica_sel = self._pick(informatica, "Informatica Pipeline")

        # --- 4. Airflow: automático ou manual ---
        print("─" * 50)
        print("ETAPA 2 — DAGs Airflow (orquestrador)")
        if auto:
            airflow_sel = [p for p in airflow if self._airflow_matches_table(p, table_short)]
            if airflow_sel:
                self._print_auto(airflow_sel, "Airflow DAG")
            else:
                print("  Nenhum DAG com match automático. Seleção manual:")
                airflow_sel = self._pick(airflow, "Airflow DAG")
        else:
            airflow_sel = self._pick(airflow, "Airflow DAG")

        # --- 5. Qlik: sempre manual ---
        search_dash = dashboard_name if dashboard_name else table_short
        all_dashboards = self.client.get_dashboards_by_name(search_dash)

        print("─" * 50)
        print("ETAPA 3 — Dashboards Qlik (downstream)")
        dashboards_sel = self._pick(all_dashboards, "Dashboard")

        # --- 6. Monta edges ---
        edges_preview = []
        for inf in informatica_sel:
            for air in airflow_sel:
                edges_preview.append((inf, "pipeline", air, "pipeline"))
        for air in airflow_sel:
            edges_preview.append((air, "pipeline", table, "table"))
        for dash in dashboards_sel:
            edges_preview.append((table, "table", dash, "dashboard"))

        if not edges_preview:
            print("\nNenhuma edge para criar. Encerrando.")
            return

        # --- 7. Resumo e confirmação ---
        print("\n" + "─" * 50)
        print("RESUMO — Edges que serão criadas:")
        for from_e, _, to_e, __ in edges_preview:
            from_fqn = from_e.get("fullyQualifiedName", from_e.get("name"))
            to_fqn = to_e.get("fullyQualifiedName", to_e.get("name"))
            print(f"  {from_fqn}")
            print(f"    └─► {to_fqn}")

        confirm = input("\nConfirmar criação? (s/N): ").strip().lower()
        if confirm != "s":
            print("Cancelado.")
            return

        # --- 8. Cria as edges ---
        print("\nCriando linhagem...")
        created = sum(
            self._create_edge(from_e, from_t, to_e, to_t)
            for from_e, from_t, to_e, to_t in edges_preview
        )
        print(f"\nTotal de edges criadas: {created} / {len(edges_preview)}")
