import json
from om_client import OpenMetadataClient


class LineageBuilder:
    def __init__(self):
        self.client = OpenMetadataClient()

    def _resolve_table(self, table_name):
        """
        Busca a tabela no OpenMetadata.
        Aceita nome simples (TF_FATURAMENTO) ou FQN completo.
        Retorna o objeto da tabela ou None.
        """
        table_short = table_name.split(".")[-1].upper()
        tables = self.client.get_table_by_name(table_name)

        if not tables:
            return None

        # 1. Match exato no campo 'name'
        exact = [t for t in tables if t.get("name", "").upper() == table_short]
        if exact:
            return exact[0]

        # 2. Match no último segmento do FQN (ex: "SNOWFLAKE.DB.SCHEMA.TF_FATURAMENTO")
        fqn_match = [t for t in tables
                     if t.get("fullyQualifiedName", "").upper().split(".")[-1] == table_short]
        if fqn_match:
            return fqn_match[0]

        # 3. Fallback: primeiro resultado
        return tables[0]

    # ─────────────────────────────────────────────
    # Detecção por conteúdo real (não por nome)
    # ─────────────────────────────────────────────

    def _pipeline_references_table(self, pipeline, table_short):
        """
        Verifica se o pipeline referencia a tabela em seus tasks:
        SQL, descrição, nome de task, sourceConfig, etc.
        """
        # Serializa tudo do pipeline como texto para busca simples
        content = json.dumps(pipeline).upper()
        return table_short.upper() in content

    def _dashboard_references_table(self, dashboard, table_short):
        """
        Verifica se o dashboard referencia a tabela em seus dataModels ou charts.
        """
        content = json.dumps(dashboard).upper()
        return table_short.upper() in content

    # ─────────────────────────────────────────────
    # Helpers de UI
    # ─────────────────────────────────────────────

    def _display(self, entity):
        fqn = entity.get("fullyQualifiedName", entity.get("name", "?"))
        display = entity.get("displayName") or ""
        return f"{fqn}  ({display})" if display else fqn

    def _pick(self, entities, label):
        if not entities:
            print(f"  Nenhum {label} encontrado.")
            return []

        print(f"\n{label}s ({len(entities)}):")
        for i, e in enumerate(entities):
            print(f"  [{i}] {self._display(e)}")

        print("Números desejados (ex: 0,2), 'all' para todos, ENTER para nenhum:")
        choice = input("> ").strip()

        if not choice:
            return []
        if choice.lower() == "all":
            return entities

        selected = []
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit() and int(part) < len(entities):
                selected.append(entities[int(part)])
        return selected

    def _create_edge(self, from_entity, from_type, to_entity, to_type):
        from_fqn = self._display(from_entity)
        to_fqn = self._display(to_entity)
        try:
            self.client.add_lineage_edge(from_entity["id"], from_type, to_entity["id"], to_type)
            print(f"  [OK] {from_fqn}  →  {to_fqn}")
            return True
        except Exception as e:
            print(f"  [ERRO] {from_fqn} → {to_fqn}: {e}")
            return False

    # ─────────────────────────────────────────────
    # Busca baseada em conteúdo real
    # ─────────────────────────────────────────────

    def _find_pipelines_by_table(self, table_short, service_filter=None):
        """
        Busca pipelines que realmente referenciam a tabela em seus tasks/SQL.
        service_filter: 'airflow' ou 'informatica' para filtrar por serviço.
        """
        print(f"  Buscando pipelines que referenciam '{table_short}'...", end=" ", flush=True)

        # Primeiro busca por nome para ter candidatos
        candidates = self.client.get_pipelines_by_name(table_short)

        if service_filter:
            candidates = [p for p in candidates
                          if service_filter.lower() in p.get("fullyQualifiedName", "").lower()]

        # Para cada candidato, busca detalhes completos e verifica referência real
        matches = []
        for p in candidates:
            try:
                details = self.client.get_pipeline_details(p["id"])
                if self._pipeline_references_table(details, table_short):
                    matches.append(details)
            except Exception:
                # Se não conseguiu detalhes, usa o que tem
                if self._pipeline_references_table(p, table_short):
                    matches.append(p)

        print(f"{len(matches)} encontrado(s).")
        return matches

    def _find_dashboards_by_table(self, table_short):
        """
        Busca dashboards que realmente referenciam a tabela em seus dataModels/charts.
        """
        print(f"  Buscando dashboards que referenciam '{table_short}'...", end=" ", flush=True)

        candidates = self.client.get_dashboards_by_name(table_short)

        matches = []
        for d in candidates:
            try:
                details = self.client.get_dashboard_details(d["id"])
                if self._dashboard_references_table(details, table_short):
                    matches.append(details)
            except Exception:
                if self._dashboard_references_table(d, table_short):
                    matches.append(d)

        print(f"{len(matches)} encontrado(s).")
        return matches

    # ─────────────────────────────────────────────
    # Comandos principais
    # ─────────────────────────────────────────────

    def explore(self, table_name):
        """Mostra o que o OpenMetadata sabe sobre a tabela e o que a referencia de verdade."""
        print(f"\n=== Explorando: {table_name} ===\n")
        table_short = table_name.split(".")[-1].upper()

        table = self._resolve_table(table_name)
        if not table:
            print(f"Tabela '{table_name}' não encontrada no OpenMetadata.")
            return None, [], []
        print(f"Tabela: {table.get('fullyQualifiedName')}")

        print("\nLinhagem já registrada no OpenMetadata:")
        try:
            lineage = self.client.get_lineage("table", table["id"])
            edges = lineage.get("edges", [])
            if edges:
                for edge in edges:
                    print(f"  {edge.get('fromEntity', {}).get('fqn', '?')} → {edge.get('toEntity', {}).get('fqn', '?')}")
            else:
                print("  Nenhuma linhagem registrada ainda.")
        except Exception as e:
            print(f"  Erro: {e}")

        print("\nBuscando quem realmente referencia essa tabela:")
        informatica = self._find_pipelines_by_table(table_short, service_filter="informatica")
        airflow = self._find_pipelines_by_table(table_short, service_filter="airflow")
        dashboards = self._find_dashboards_by_table(table_short)

        if informatica:
            print("\n  Informatica pipelines:")
            for p in informatica:
                print(f"    {self._display(p)}")
        if airflow:
            print("\n  Airflow DAGs:")
            for p in airflow:
                print(f"    {self._display(p)}")
        if dashboards:
            print("\n  Dashboards Qlik:")
            for d in dashboards:
                print(f"    {self._display(d)}")

        return table, informatica + airflow, dashboards

    def build(self, table_name, auto=False):
        """
        Constrói linhagem: Informatica → Airflow → Snowflake → Qlik

        Detecta relações reais pelo conteúdo das entidades (tasks, dataModels),
        não apenas pelo nome.
        """
        print(f"\n=== Build de linhagem: {table_name} ===")
        print("Fluxo: Informatica  →  Airflow  →  Snowflake  →  Qlik\n")

        table_short = table_name.split(".")[-1].upper()

        # 1. Tabela Snowflake
        table = self._resolve_table(table_name)
        if not table:
            print(f"Tabela '{table_name}' não encontrada no OpenMetadata.")
            return
        print(f"Tabela alvo: {table.get('fullyQualifiedName')}\n")

        # 2. Busca por conteúdo real
        print("Detectando relações reais...")
        informatica = self._find_pipelines_by_table(table_short, service_filter="informatica")
        airflow = self._find_pipelines_by_table(table_short, service_filter="airflow")
        dashboards = self._find_dashboards_by_table(table_short)

        # 3. Seleção
        print("\n" + "─" * 50)
        print("ETAPA 1 — Informatica Cloud (upstream)")
        informatica_sel = informatica if auto else self._pick(informatica, "Informatica Pipeline")

        print("─" * 50)
        print("ETAPA 2 — Airflow DAGs")
        airflow_sel = airflow if auto else self._pick(airflow, "Airflow DAG")

        print("─" * 50)
        print("ETAPA 3 — Dashboards Qlik (downstream)")
        dashboards_sel = dashboards if auto else self._pick(dashboards, "Dashboard")

        # 4. Monta edges
        edges_preview = []
        for inf in informatica_sel:
            for air in airflow_sel:
                edges_preview.append((inf, "pipeline", air, "pipeline"))
        for air in airflow_sel:
            edges_preview.append((air, "pipeline", table, "table"))
        for dash in dashboards_sel:
            edges_preview.append((table, "table", dash, "dashboard"))

        if not edges_preview:
            print("\nNenhuma edge para criar. Encerrando.")
            return

        # 5. Resumo e confirmação
        print("\n" + "─" * 50)
        print("RESUMO — Edges que serão criadas:")
        for from_e, _, to_e, __ in edges_preview:
            print(f"  {self._display(from_e)}")
            print(f"    └─► {self._display(to_e)}")

        confirm = input("\nConfirmar criação? (s/N): ").strip().lower()
        if confirm != "s":
            print("Cancelado.")
            return

        # 6. Cria
        print("\nCriando linhagem...")
        created = sum(
            self._create_edge(from_e, from_t, to_e, to_t)
            for from_e, from_t, to_e, to_t in edges_preview
        )
        print(f"\nTotal de edges criadas: {created} / {len(edges_preview)}")
